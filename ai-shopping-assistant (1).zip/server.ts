import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes first
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages } = req.body;
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "messages array is required" });
      }

      const currentApiKey = process.env.GEMINI_API_KEY;
      if (!currentApiKey) {
        throw new Error("GEMINI_API_KEY is not configured in the server environment. Please set it in Settings > Secrets.");
      }

      // Lazy-initialize client to pick up dynamic key changes
      const ai = new GoogleGenAI({
        apiKey: currentApiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      // Map messages to Gemini format and sanitize
      const rawContents = messages
        .filter((msg) => msg && msg.content && msg.content.trim())
        .map((msg) => ({
          role: msg.role === "assistant" ? "model" : "user",
          parts: [{ text: msg.content }],
        }));

      // Ensure the conversation starts with a user message (Gemini requirement)
      while (rawContents.length > 0 && rawContents[0].role === "model") {
        rawContents.shift();
      }

      // Merge consecutive identical roles to guarantee strict alternating user/model pattern
      const contents: typeof rawContents = [];
      for (const current of rawContents) {
        if (contents.length === 0) {
          contents.push(current);
        } else {
          const last = contents[contents.length - 1];
          if (last.role === current.role) {
            last.parts[0].text += "\n\n" + current.parts[0].text;
          } else {
            contents.push(current);
          }
        }
      }

      if (contents.length === 0) {
        return res.status(400).json({ error: "No valid user messages found in chat history" });
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: contents,
        config: {
          systemInstruction: `You are an expert AI Shopping Assistant for ShopAI Portal.
Your goal is to recommend, compare, and explain products for users (specifically Laptops, Mobiles, and Smart TVs) to help them make perfect buying decisions.

Key Directives:
1. Recommend real, actual products using your Google Search Grounding capabilities. Do not invent products or specs.
2. Compare products side-by-side. Highlight critical specifications in a clear, easy-to-read layout.
3. Clearly explain why one product is better suited for their specific request.
4. Designate a clear "Winner" or "Recommended Choice" with a brief, bulleted explanation.
5. If the user is searching for specific mobiles, laptops, or TVs (e.g., "show me OnePlus phones", "find Samsung TVs", "search RTX laptops"), use web grounding search to find specific models and details.
6. Keep your responses short, friendly, highly structured, and written in clean markdown.
7. Use the user's currency (e.g. INR/₹, always mention approximate current pricing in Rupees if in India or if inferred, otherwise USD/$).

CRITICAL DATA SYNCHRONIZATION DIRECTIVE:
Whenever you recommend, list, search, or talk about specific products (such as laptops, mobiles, or TVs), you must ALWAYS append a structured JSON array at the very end of your response inside a block tagged with the language 'product-data-json'.
The JSON must be a raw JSON array matching this exact TypeScript structure:
interface Product {
  id: string; // unique lowercase slug based on the product name, e.g. "web-oneplus-12r"
  category: "laptop" | "mobile" | "tv" | "other";
  name: string; // full product name with model/year
  price: string; // approximate current price formatted as currency, e.g. "₹39,999" or "₹1,24,900" or "$499"
  rating: number; // integer rating from 1 to 5 (assign based on review trends)
  specs: { [key: string]: string }; // exact spec keys matching the category's standard schema below
  pros: string[]; // 1-3 clear pro points
  cons: string[]; // 1-2 clear con/limit points
}

Category Specification Schema (You must match these spec keys exactly based on the category of the product):
- For "laptop":
  - "Processor"
  - "Graphics/GPU"
  - "RAM Memory"
  - "Storage"
  - "Display/Screen"
  - "Battery/Power"
- For "mobile":
  - "Processor"
  - "Display"
  - "Camera"
  - "RAM/Storage"
  - "Battery/Charging"
  - "Operating System"
- For "tv":
  - "Screen Size"
  - "Display Tech"
  - "Refresh Rate"
  - "Sound Output"
  - "Smart OS"
  - "Connectivity"
- For "other": Use 4-6 relevant tech specifications.

Example block structure at the very end of your response (must start with \`\`\`product-data-json and end with \`\`\`):
\`\`\`product-data-json
[
  {
    "id": "web-samsung-s24",
    "category": "mobile",
    "name": "Samsung Galaxy S24 Ultra",
    "price": "₹1,29,999",
    "rating": 5,
    "specs": {
      "Processor": "Snapdragon 8 Gen 3 for Galaxy (4nm)",
      "Display": "6.8'' Dynamic AMOLED 2X (120Hz, 2600 nits)",
      "Camera": "200MP Main (OIS) + 50MP Periscope + 10MP Telephoto + 12MP Ultra-wide",
      "RAM/Storage": "12GB LPDDR5X | 256GB/512GB UFS 4.0",
      "Battery/Charging": "5000mAh Battery with 45W Fast Charging",
      "Operating System": "One UI 6.1 based on Android 14"
    },
    "pros": ["Incredible 200MP detail with 5x optical zoom", "Stunning anti-reflective armor screen", "7 years of full OS updates guaranteed"],
    "cons": ["Very expensive", "Bulky and heavy to hold"]
  }
]
\`\`\`

If you don't find or recommend any specific products in your response, do not include the \`\`\`product-data-json block.`,
          tools: [{ googleSearch: {} }],
        },
      });

      const reply = response.text || "I apologize, but I am unable to generate a response right now. Please try again.";
      const groundingMetadata = response.candidates?.[0]?.groundingMetadata || null;

      res.json({ reply, groundingMetadata });
    } catch (error: any) {
      console.error("Gemini API Error:", error);
      res.status(500).json({ error: error?.message || "An error occurred while contacting the AI model." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
