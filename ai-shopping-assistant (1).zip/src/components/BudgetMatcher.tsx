import React, { useState, useEffect } from "react";
import { Product } from "../types";
import { Sliders, CheckCircle, AlertCircle, Sparkles, Flame, Battery, Cpu, Smartphone, Tv } from "lucide-react";
import { motion } from "motion/react";

interface BudgetMatcherProps {
  products: Product[];
  activeCategory: "laptop" | "mobile" | "tv" | "other";
  sliderLabels: {
    weight1: string;
    weight2: string;
    weight3: string;
    weight4: string;
    weight5: string;
  };
  defaultBudget: number;
}

interface Weights {
  w1: number;
  w2: number;
  w3: number;
  w4: number;
  w5: number;
}

export default function BudgetMatcher({
  products,
  activeCategory,
  sliderLabels,
  defaultBudget,
}: BudgetMatcherProps) {
  const [targetBudget, setTargetBudget] = useState<number>(defaultBudget);
  const [weights, setWeights] = useState<Weights>({
    w1: 4,
    w2: 4,
    w3: 3,
    w4: 3,
    w5: 2,
  });

  const [scoredProducts, setScoredProducts] = useState<{ product: Product; score: number; budgetDelta: number }[]>([]);

  // Update target budget when active category changes
  useEffect(() => {
    setTargetBudget(defaultBudget);
  }, [activeCategory, defaultBudget]);

  const parsePrice = (priceStr: string): number => {
    const cleanStr = priceStr.replace(/[^0-9]/g, "");
    return parseInt(cleanStr, 10) || 0;
  };

  useEffect(() => {
    const scored = products.map((product) => {
      const price = parsePrice(product.price);
      let score = 50; // Base score

      // 1. Budget Fit Score (Up to 35 points)
      let budgetDelta = price - targetBudget;
      if (budgetDelta <= 0) {
        // Within budget: higher score if close to target budget (best value) or cheaper
        score += 35;
      } else {
        // Over budget penalty: penalize based on percentage over budget
        const overPercent = budgetDelta / targetBudget;
        score += Math.max(0, 35 - overPercent * 100);
      }

      // 2. Specifications Capability (Up to 65 points)
      let r1 = 3, r2 = 3, r3 = 3, r4 = 3, r5 = 3;

      const specStr = JSON.stringify(product.specs).toLowerCase();

      if (activeCategory === "laptop") {
        // w1: Coding Performance (CPU)
        r1 = 3;
        if (specStr.includes("i5") || specStr.includes("ryzen 5")) r1 = 4;
        if (specStr.includes("i7") || specStr.includes("ryzen 7") || specStr.includes("12th") || specStr.includes("13th") || specStr.includes("6600h")) r1 = 5;
        if (specStr.includes("16gb")) r1 += 0.5;

        // w2: Gaming Power (GPU)
        r2 = 2.5;
        if (specStr.includes("rtx 2050")) r2 = 4;
        if (specStr.includes("rtx 3050") || specStr.includes("rtx 4050")) r2 = 5;

        // w3: Battery Longevity
        r3 = 3;
        if (specStr.includes("52.5whr") || specStr.includes("5h") || specStr.includes("6h") || specStr.includes("ryzen")) r3 = 4.5;
        if (specStr.includes("rtx 3050") && specStr.includes("intel")) r3 = 2.5; // heavy power draw

        // w4: Display Quality
        r4 = 3;
        if (specStr.includes("ips") || specStr.includes("120hz")) r4 = 4;
        if (specStr.includes("144hz") || specStr.includes("oled") || specStr.includes("srgb")) r4 = 5;

        // w5: Portability
        r5 = 4;
        if (specStr.includes("rtx")) r5 = 2.5; // heavy dual fans
      } else if (activeCategory === "mobile") {
        // w1: Processing Power
        r1 = 3;
        if (specStr.includes("snapdragon 7") || specStr.includes("dimensity")) r1 = 4.5;
        if (specStr.includes("snapdragon 8") || specStr.includes("exynos 1380")) r1 = 4;

        // w2: Camera Capabilities
        r2 = 3;
        if (specStr.includes("50mp") && specStr.includes("ois")) r2 = 4.5;
        if (specStr.includes("200mp")) r2 = 5;

        // w3: Battery & Fast Charge
        r3 = 3;
        if (specStr.includes("5000mah")) r3 = 4;
        if (specStr.includes("67w") || specStr.includes("100w") || specStr.includes("supervooc")) r3 = 5;

        // w4: AMOLED Display
        r4 = 3;
        if (specStr.includes("amoled") || specStr.includes("120hz")) r4 = 4.5;
        if (specStr.includes("1.5k") || specStr.includes("1800 nits")) r4 = 5;

        // w5: Sleek Build & Software
        r5 = 3.5;
        if (specStr.includes("oxygenos") || specStr.includes("one ui")) r5 = 5;
        if (specStr.includes("bloatware")) r5 = 3;
      } else if (activeCategory === "tv") {
        // w1: Cinematic Display Tech
        r1 = 3;
        if (specStr.includes("4k") || specStr.includes("dolby vision")) r1 = 4.5;
        if (specStr.includes("hdr10+") || specStr.includes("crystal processor")) r1 = 5;

        // w2: Sound Output
        r2 = 3;
        if (specStr.includes("24w")) r2 = 4;
        if (specStr.includes("30w") || specStr.includes("atmos")) r2 = 5;

        // w3: Smart TV OS
        r3 = 3.5;
        if (specStr.includes("google tv") || specStr.includes("tizen")) r3 = 5;
        if (specStr.includes("android tv 11")) r3 = 4;

        // w4: Connectivity
        r4 = 3;
        if (specStr.includes("3 hdmi") || specStr.includes("usb")) r4 = 4.5;

        // w5: Refresh Rate (Console)
        r5 = 3;
        if (specStr.includes("60 hz") || specStr.includes("60hz")) r5 = 4.5;
        if (specStr.includes("120hz")) r5 = 5;
      } else {
        // Other Category generic specs
        r1 = product.rating;
        r2 = product.pros.length > 2 ? 5 : 4;
        r3 = product.cons.length > 1 ? 3 : 4;
      }

      const totalWeights = weights.w1 + weights.w2 + weights.w3 + weights.w4 + weights.w5;
      const weightedSpecsScore =
        (weights.w1 * r1 +
          weights.w2 * r2 +
          weights.w3 * r3 +
          weights.w4 * r4 +
          weights.w5 * r5) /
        totalWeights;

      score += (weightedSpecsScore / 5) * 65;

      const finalScore = Math.min(100, Math.max(0, Math.round(score)));

      return {
        product,
        score: finalScore,
        budgetDelta,
      };
    });

    scored.sort((a, b) => b.score - a.score);
    setScoredProducts(scored);
  }, [targetBudget, weights, products, activeCategory]);

  const updateWeight = (field: keyof Weights, value: number) => {
    setWeights((prev) => ({ ...prev, [field]: value }));
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(val);
  };

  // Dynamically set budget slider bounds depending on category
  const getBudgetBounds = () => {
    if (activeCategory === "laptop") {
      return { min: 30000, max: 120000, step: 5000 };
    } else if (activeCategory === "mobile") {
      return { min: 10000, max: 60000, step: 2000 };
    } else {
      return { min: 15000, max: 80000, step: 2000 };
    }
  };

  const { min, max, step } = getBudgetBounds();

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <Sliders className="w-5 h-5 text-indigo-600" />
          Priority Scorer ({activeCategory === "laptop" ? "Laptops" : activeCategory === "mobile" ? "Mobiles" : "TVs"})
        </h3>
        <p className="text-xs text-slate-500">
          Slide your target price and specific parameters to dynamically rank products for this category.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 bg-slate-50 p-4 border border-slate-200 rounded-2xl text-xs">
        {/* Sliders Container */}
        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="font-bold text-slate-700">Target Budget:</span>
              <span className="font-bold text-indigo-600 font-mono text-sm bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-100">
                {formatCurrency(targetBudget)}
              </span>
            </div>
            <input
              type="range"
              min={min}
              max={max}
              step={step}
              value={targetBudget}
              onChange={(e) => setTargetBudget(parseInt(e.target.value, 10))}
              className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>{formatCurrency(min)}</span>
              <span>Target: {formatCurrency(defaultBudget)}</span>
              <span>{formatCurrency(max)}</span>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <span className="font-bold text-slate-700 block border-b border-slate-200 pb-1">Prioritize Custom Features:</span>
            
            {/* Weight 1 */}
            <div>
              <div className="flex justify-between text-slate-600 mb-0.5">
                <span className="font-medium">{sliderLabels.weight1}</span>
                <span className="font-semibold font-mono">{weights.w1}/5</span>
              </div>
              <input
                type="range"
                min="1"
                max="5"
                value={weights.w1}
                onChange={(e) => updateWeight("w1", parseInt(e.target.value))}
                className="w-full h-1 bg-slate-200 rounded accent-indigo-500"
              />
            </div>

            {/* Weight 2 */}
            <div>
              <div className="flex justify-between text-slate-600 mb-0.5">
                <span className="font-medium">{sliderLabels.weight2}</span>
                <span className="font-semibold font-mono">{weights.w2}/5</span>
              </div>
              <input
                type="range"
                min="1"
                max="5"
                value={weights.w2}
                onChange={(e) => updateWeight("w2", parseInt(e.target.value))}
                className="w-full h-1 bg-slate-200 rounded accent-indigo-500"
              />
            </div>

            {/* Weight 3 */}
            <div>
              <div className="flex justify-between text-slate-600 mb-0.5">
                <span className="font-medium">{sliderLabels.weight3}</span>
                <span className="font-semibold font-mono">{weights.w3}/5</span>
              </div>
              <input
                type="range"
                min="1"
                max="5"
                value={weights.w3}
                onChange={(e) => updateWeight("w3", parseInt(e.target.value))}
                className="w-full h-1 bg-slate-200 rounded accent-indigo-500"
              />
            </div>

            {/* Weight 4 */}
            <div>
              <div className="flex justify-between text-slate-600 mb-0.5">
                <span className="font-medium">{sliderLabels.weight4}</span>
                <span className="font-semibold font-mono">{weights.w4}/5</span>
              </div>
              <input
                type="range"
                min="1"
                max="5"
                value={weights.w4}
                onChange={(e) => updateWeight("w4", parseInt(e.target.value))}
                className="w-full h-1 bg-slate-200 rounded accent-indigo-500"
              />
            </div>

            {/* Weight 5 */}
            <div>
              <div className="flex justify-between text-slate-600 mb-0.5">
                <span className="font-medium">{sliderLabels.weight5}</span>
                <span className="font-semibold font-mono">{weights.w5}/5</span>
              </div>
              <input
                type="range"
                min="1"
                max="5"
                value={weights.w5}
                onChange={(e) => updateWeight("w5", parseInt(e.target.value))}
                className="w-full h-1 bg-slate-200 rounded accent-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Dynamic Results Display */}
        <div className="flex flex-col justify-between">
          <div className="space-y-3">
            <span className="font-bold text-slate-700 block border-b border-slate-200 pb-1">Mathematical Matching Rankings:</span>
            {products.length === 0 ? (
              <p className="text-slate-400 py-4 text-center">No products compared in this category yet. Add items to see recommendations!</p>
            ) : (
              <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
                {scoredProducts.map(({ product, score, budgetDelta }) => {
                  const isWithinBudget = budgetDelta <= 0;
                  return (
                    <div
                      key={product.id}
                      className="flex items-center justify-between p-2.5 bg-white border border-slate-200 rounded-xl shadow-xs"
                    >
                      <div className="space-y-0.5 max-w-[70%]">
                        <div className="font-bold text-slate-800 line-clamp-1">{product.name}</div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-indigo-600 font-semibold font-mono">{product.price}</span>
                          {isWithinBudget ? (
                            <span className="inline-flex items-center gap-0.5 text-[9px] bg-green-50 text-green-700 font-medium px-1 rounded">
                              <CheckCircle className="w-2.5 h-2.5" /> In Budget
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-0.5 text-[9px] bg-amber-50 text-amber-700 font-medium px-1 rounded">
                              <AlertCircle className="w-2.5 h-2.5" /> +{formatCurrency(budgetDelta)} Over
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="text-right flex flex-col items-end">
                        <div className="inline-flex items-center gap-1 bg-indigo-50 text-indigo-700 text-xs font-bold px-2 py-1 rounded-lg border border-indigo-100">
                          <Sparkles className="w-3.5 h-3.5 text-indigo-500 animate-pulse" />
                          <span>{score}% Match</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="bg-amber-50 border border-amber-100 rounded-xl p-3 text-[11px] text-slate-600 mt-3">
            <div className="flex gap-1.5 items-start">
              <Sparkles className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-amber-900 block">Pro Buying Tip:</span>
                {activeCategory === "laptop" && "Prioritize at least 16GB RAM and H-series processors for Docker/IDEs, plus dedicated graphics like the RTX 3050 for smooth gaming."}
                {activeCategory === "mobile" && "For the best mobile experience, look for an AMOLED screen with a 120Hz refresh rate and OIS support on the camera lens for steady photos."}
                {activeCategory === "tv" && "Always check for Google TV or Tizen OS for maximum smart app compatibility. Look for Dolby Vision and at least 3 HDMI ports."}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
