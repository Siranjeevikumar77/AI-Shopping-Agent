import React, { useState, useEffect } from "react";
import { Product } from "../types";
import { Star, Plus, Trash2, Check, Award, ThumbsUp, ShieldAlert, Laptop, Smartphone, Tv } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ComparisonMatrixProps {
  products: Product[];
  activeCategory: "laptop" | "mobile" | "tv" | "other";
  specKeys: string[];
  onAddProduct: (product: Product) => void;
  onRemoveProduct: (id: string) => void;
}

export default function ComparisonMatrix({
  products,
  activeCategory,
  specKeys,
  onAddProduct,
  onRemoveProduct,
}: ComparisonMatrixProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: "",
    price: "",
    specs: {},
    pros: [],
    cons: [],
    rating: 5,
  });
  const [proInput, setProInput] = useState("");
  const [conInput, setConInput] = useState("");

  // Clear form specs when category changes
  useEffect(() => {
    setNewProduct({
      name: "",
      price: "",
      specs: {},
      pros: [],
      cons: [],
      rating: 5,
    });
  }, [activeCategory]);

  const handleAddPro = () => {
    if (proInput.trim()) {
      setNewProduct((prev) => ({
        ...prev,
        pros: [...(prev.pros || []), proInput.trim()],
      }));
      setProInput("");
    }
  };

  const handleAddCon = () => {
    if (conInput.trim()) {
      setNewProduct((prev) => ({
        ...prev,
        cons: [...(prev.cons || []), conInput.trim()],
      }));
      setConInput("");
    }
  };

  const handleSpecChange = (key: string, value: string) => {
    setNewProduct((prev) => ({
      ...prev,
      specs: {
        ...(prev.specs || {}),
        [key]: value,
      },
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.name || !newProduct.price) return;

    // Build specs ensuring all standard keys have at least a placeholder
    const finalSpecs: { [key: string]: string } = {};
    specKeys.forEach((k) => {
      finalSpecs[k] = newProduct.specs?.[k] || "Standard Specification";
    });

    const product: Product = {
      id: "prod_" + Date.now(),
      category: activeCategory,
      name: newProduct.name,
      price: newProduct.price.startsWith("₹") ? newProduct.price : "₹" + newProduct.price,
      specs: finalSpecs,
      pros: newProduct.pros || [],
      cons: newProduct.cons || [],
      rating: newProduct.rating || 4,
    };

    onAddProduct(product);
    setNewProduct({
      name: "",
      price: "",
      specs: {},
      pros: [],
      cons: [],
      rating: 5,
    });
    setProInput("");
    setConInput("");
    setShowAddForm(false);
  };

  const getWinnerId = () => {
    if (products.length === 0) return null;
    let best = products[0];
    for (const p of products) {
      if (p.rating > best.rating) {
        best = p;
      }
    }
    return best.id;
  };

  const winnerId = getWinnerId();

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-500" />
            E-Commerce Visual Spec Board
          </h3>
          <p className="text-xs text-slate-500">
            Compare key technical specifications side-by-side to choose the perfect model.
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-sm transition"
          id="btn-add-product"
        >
          <Plus className="w-4 h-4 text-amber-400" /> Add Custom {activeCategory === "laptop" ? "Laptop" : activeCategory === "mobile" ? "Mobile" : "TV"}
        </button>
      </div>

      <AnimatePresence>
        {showAddForm && (
          <motion.form
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleSubmit}
            className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs space-y-4 overflow-hidden shadow-inner"
            id="form-add-product"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Product Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder={`e.g. OnePlus Nord CE4 or Samsung S24`}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg outline-none focus:border-indigo-500 text-xs"
                  value={newProduct.name}
                  onChange={(e) =>
                    setNewProduct((prev) => ({ ...prev, name: e.target.value }))
                  }
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Price (INR) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 24,999"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg outline-none focus:border-indigo-500 text-xs"
                  value={newProduct.price}
                  onChange={(e) =>
                    setNewProduct((prev) => ({ ...prev, price: e.target.value }))
                  }
                />
              </div>

              {/* Dynamic Specifications Inputs based on Category */}
              {specKeys.map((key) => (
                <div key={key}>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    {key}
                  </label>
                  <input
                    type="text"
                    placeholder={`Enter details for ${key}`}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg outline-none focus:border-indigo-500 text-xs"
                    value={newProduct.specs?.[key] || ""}
                    onChange={(e) => handleSpecChange(key, e.target.value)}
                  />
                </div>
              ))}
            </div>

            {/* Pros and Cons */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Key Pros
                </label>
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    placeholder="Add a pro..."
                    className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-lg outline-none focus:border-indigo-500 text-xs"
                    value={proInput}
                    onChange={(e) => setProInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), handleAddPro())}
                  />
                  <button
                    type="button"
                    onClick={handleAddPro}
                    className="px-3 py-2 bg-slate-200 hover:bg-slate-300 rounded-lg font-semibold"
                  >
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {(newProduct.pros || []).map((pro, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1 bg-green-50 text-green-700 px-2 py-0.5 rounded text-[10px] border border-green-100"
                    >
                      <Check className="w-3 h-3 text-green-500" /> {pro}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Key Cons
                </label>
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    placeholder="Add a con..."
                    className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-lg outline-none focus:border-indigo-500 text-xs"
                    value={conInput}
                    onChange={(e) => setConInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), handleAddCon())}
                  />
                  <button
                    type="button"
                    onClick={handleAddCon}
                    className="px-3 py-2 bg-slate-200 hover:bg-slate-300 rounded-lg font-semibold"
                  >
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {(newProduct.cons || []).map((con, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1 bg-red-50 text-red-700 px-2 py-0.5 rounded text-[10px] border border-red-100"
                    >
                      × {con}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-slate-200">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-600">Assigned Rating:</span>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      type="button"
                      key={star}
                      onClick={() => setNewProduct((prev) => ({ ...prev, rating: star }))}
                    >
                      <Star
                        className={`w-4 h-4 ${
                          star <= (newProduct.rating || 5)
                            ? "fill-amber-400 text-amber-400"
                            : "text-slate-300"
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold"
                >
                  Save Product
                </button>
              </div>
            </div>
          </motion.form>
        )}
      </AnimatePresence>

      {products.length === 0 ? (
        <div className="text-center py-12 bg-slate-50 border border-dashed border-slate-200 rounded-2xl">
          <p className="text-slate-400 text-xs">No products in this category compared yet.</p>
          <p className="text-[11px] text-slate-400 mt-1">
            Click 'Add Custom Product' or talk to our live AI Assistant to fetch newer specs!
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto border border-slate-200 rounded-2xl shadow-sm bg-white">
          <table className="w-full text-xs text-left border-collapse min-w-[600px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="p-3 font-semibold text-slate-600 min-w-[150px]">Specifications</th>
                {products.map((product) => (
                  <th key={product.id} className="p-3 min-w-[200px] border-l border-slate-100">
                    <div className="relative group pr-6">
                      {winnerId === product.id && (
                        <span className="absolute -top-1.5 -right-1.5 flex items-center gap-0.5 bg-amber-100 text-amber-800 text-[9px] font-bold px-1.5 py-0.5 rounded-full border border-amber-300">
                          <Award className="w-3 h-3 text-amber-600" /> TOP-RATED
                        </span>
                      )}
                      <div className="font-bold text-slate-800 line-clamp-1">{product.name}</div>
                      <div className="text-indigo-600 font-bold text-sm mt-0.5">{product.price}</div>
                      <button
                        onClick={() => onRemoveProduct(product.id)}
                        className="absolute right-0 top-0 text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition"
                        title="Remove product"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {/* Rating Row */}
              <tr className="border-b border-slate-100 hover:bg-slate-50/50">
                <td className="p-3 font-semibold text-slate-500">Expert & User Rating</td>
                {products.map((product) => (
                  <td key={product.id} className="p-3 border-l border-slate-100">
                    <div className="flex items-center gap-1">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-3.5 h-3.5 ${
                              star <= product.rating
                                ? "fill-amber-400 text-amber-400"
                                : "text-slate-200"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-[10px] text-slate-400 font-medium">({product.rating}.0)</span>
                    </div>
                  </td>
                ))}
              </tr>

              {/* Dynamic Categories Specification Rows */}
              {specKeys.map((key) => (
                <tr key={key} className="border-b border-slate-100 hover:bg-slate-50/50">
                  <td className="p-3 font-semibold text-slate-500">{key}</td>
                  {products.map((product) => (
                    <td key={product.id} className="p-3 text-slate-700 border-l border-slate-100 leading-relaxed font-medium">
                      {product.specs[key] || "—"}
                    </td>
                  ))}
                </tr>
              ))}

              {/* Pros Row */}
              <tr className="border-b border-slate-100 hover:bg-slate-50/50">
                <td className="p-3 font-semibold text-green-600">
                  <div className="flex items-center gap-1">
                    <ThumbsUp className="w-3.5 h-3.5" /> Key Pros
                  </div>
                </td>
                {products.map((product) => (
                  <td key={product.id} className="p-3 border-l border-slate-100">
                    <ul className="space-y-1">
                      {product.pros.map((pro, i) => (
                        <li key={i} className="flex items-start gap-1 text-[11px] text-slate-600">
                          <Check className="w-3 h-3 text-green-500 shrink-0 mt-0.5" />
                          <span>{pro}</span>
                        </li>
                      ))}
                      {product.pros.length === 0 && (
                        <span className="text-slate-400 text-[10px]">None listed</span>
                      )}
                    </ul>
                  </td>
                ))}
              </tr>

              {/* Cons Row */}
              <tr className="hover:bg-slate-50/50">
                <td className="p-3 font-semibold text-red-500">
                  <div className="flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5" /> Limits / Cons
                  </div>
                </td>
                {products.map((product) => (
                  <td key={product.id} className="p-3 border-l border-slate-100">
                    <ul className="space-y-1">
                      {product.cons.map((con, i) => (
                        <li key={i} className="flex items-start gap-1 text-[11px] text-slate-600">
                          <span className="text-red-500 shrink-0 font-bold">•</span>
                          <span>{con}</span>
                        </li>
                      ))}
                      {product.cons.length === 0 && (
                        <span className="text-slate-400 text-[10px]">None listed</span>
                      )}
                    </ul>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
