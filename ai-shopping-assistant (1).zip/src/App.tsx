import React, { useState, useRef, useEffect } from "react";
import { Message, Product, User } from "./types";
import ComparisonMatrix from "./components/ComparisonMatrix";
import BudgetMatcher from "./components/BudgetMatcher";
import { CATEGORIES, INITIAL_PRODUCTS } from "./data";
import { 
  auth as firebaseAuth, 
  db as firebaseDb, 
  firebaseEnabled, 
  handleFirestoreError, 
  OperationType 
} from "./firebase";
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut as firebaseSignOut, 
  updateProfile 
} from "firebase/auth";
import { 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  getDocs 
} from "firebase/firestore";
import {
  MessageSquare,
  Sparkles,
  Send,
  Trash2,
  Cpu,
  Laptop,
  CheckCircle,
  HelpCircle,
  TrendingUp,
  RotateCcw,
  ExternalLink,
  ChevronRight,
  Bookmark,
  Shield,
  Lightbulb,
  Search,
  Filter,
  ShoppingCart,
  Tag,
  Star,
  Check,
  ChevronDown,
  ThumbsUp,
  AlertCircle,
  Award,
  Info,
  Heart,
  Percent,
  Truck,
  Zap,
  Smartphone,
  Tv
} from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: `Welcome to **ShopAI Assistant** — your personalized Flipkart & Amazon-style smart buying portal! 🛒

I am here to help you recommend, compare, and evaluate products across multiple categories including **Mobiles, Smart TVs, and Laptops** under any budget!

How can I help you today?
* **💻 Laptops**: Compare models, process specifications, or calculate coding and gaming performance.
* **📱 Mobiles**: Search for high-end photography cameras, processors, or battery endurance.
* **📺 Smart TVs**: Find the best 4K Dolby Vision panels, loud speaker outputs, and smart OS platforms.

I have preloaded the top 3 best-selling options in each category. Switch categories using the tabs above and ask me anything to find your perfect match!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [activeCategory, setActiveCategory] = useState<"laptop" | "mobile" | "tv" | "other">("laptop");
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<"compare" | "scorer">("compare");
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [selectedPriority, setSelectedPriority] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [savedProducts, setSavedProducts] = useState<string[]>([]);
  const [notification, setNotification] = useState<string | null>(null);

  // Authentication State
  const [user, setUser] = useState<User | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "signup">("login");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authName, setAuthName] = useState("");
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authDropdownOpen, setAuthDropdownOpen] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Sync state on boot
  useEffect(() => {
    if (firebaseEnabled && firebaseAuth) {
      const unsubscribe = firebaseAuth.onAuthStateChanged(async (firebaseUser) => {
        if (firebaseUser) {
          const mappedUser: User = {
            uid: firebaseUser.uid,
            email: firebaseUser.email || "",
            displayName: firebaseUser.displayName || firebaseUser.email?.split("@")[0] || "Shopper",
            isDemo: false,
          };
          setUser(mappedUser);
          await syncFromCloud(firebaseUser.uid);
        } else {
          setUser(null);
        }
      });
      return () => unsubscribe();
    } else {
      // Local session check
      const savedUser = localStorage.getItem("shopai_mock_user");
      if (savedUser) {
        try {
          const parsed = JSON.parse(savedUser) as User;
          setUser(parsed);
          const savedWish = localStorage.getItem(`shopai_wishlist_${parsed.uid}`);
          if (savedWish) {
            setSavedProducts(JSON.parse(savedWish));
          }
          const localCustomsStr = localStorage.getItem(`shopai_customs_${parsed.uid}`);
          if (localCustomsStr) {
            const localCustoms = JSON.parse(localCustomsStr) as Product[];
            setProducts((prev) => {
              const updated = [...prev];
              localCustoms.forEach((c) => {
                if (!updated.some((p) => p.id === c.id)) {
                  updated.push(c);
                }
              });
              return updated;
            });
          }
        } catch (e) {
          console.error("Local session parsing failed:", e);
        }
      }
    }
  }, []);

  const syncFromCloud = async (userId: string) => {
    if (!firebaseEnabled || !firebaseDb) return;
    try {
      // 1. Fetch Wishlist
      const wishlistRef = doc(firebaseDb, "users", userId, "wishlist", "main");
      const wishlistSnap = await getDoc(wishlistRef);
      if (wishlistSnap.exists()) {
        const data = wishlistSnap.data();
        if (data && Array.isArray(data.saved)) {
          setSavedProducts(data.saved);
        }
      }

      // 2. Fetch Custom Products
      const customProductsCol = collection(firebaseDb, "users", userId, "custom_products");
      const querySnap = await getDocs(customProductsCol);
      const customProds: Product[] = [];
      querySnap.forEach((doc) => {
        customProds.push(doc.data() as Product);
      });

      if (customProds.length > 0) {
        setProducts((prev) => {
          const updated = [...prev];
          customProds.forEach((cp) => {
            if (!updated.some((p) => p.id === cp.id)) {
              updated.push(cp);
            }
          });
          return updated;
        });
      }
    } catch (error) {
      console.error("Failed to sync cloud session:", error);
      handleFirestoreError(error, OperationType.GET, `users/${userId}/sync`);
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError(null);

    const email = authEmail.trim();
    const password = authPassword.trim();
    const name = authName.trim();

    if (!email || !password) {
      setAuthError("Please provide both email and password.");
      setAuthLoading(false);
      return;
    }

    try {
      if (authMode === "signup") {
        if (!name) {
          setAuthError("Full Name is required to build an account.");
          setAuthLoading(false);
          return;
        }

        if (firebaseEnabled && firebaseAuth) {
          const credential = await createUserWithEmailAndPassword(firebaseAuth, email, password);
          if (credential.user) {
            await updateProfile(credential.user, { displayName: name });
            const registeredUser: User = {
              uid: credential.user.uid,
              email: credential.user.email || email,
              displayName: name,
              isDemo: false,
            };
            setUser(registeredUser);
            // Save initial doc in users collection
            try {
              const userDocRef = doc(firebaseDb!, "users", credential.user.uid);
              await setDoc(userDocRef, {
                uid: credential.user.uid,
                email: credential.user.email,
                displayName: name,
                createdAt: new Date().toISOString(),
                isDemo: false
              });
            } catch (dbErr) {
              handleFirestoreError(dbErr, OperationType.WRITE, `users/${credential.user.uid}`);
            }
          }
        } else {
          // Local account sandbox
          const accountsStr = localStorage.getItem("shopai_accounts") || "[]";
          const accounts = JSON.parse(accountsStr);
          if (accounts.some((a: any) => a.email.toLowerCase() === email.toLowerCase())) {
            throw new Error("An account with this email already exists.");
          }
          const newUser: User = {
            uid: "local_" + Math.random().toString(36).substring(2, 9),
            email,
            displayName: name,
            isDemo: true,
          };
          accounts.push({ ...newUser, password });
          localStorage.setItem("shopai_accounts", JSON.stringify(accounts));
          localStorage.setItem("shopai_mock_user", JSON.stringify(newUser));
          setUser(newUser);
        }
        triggerNotification(`Welcome, ${name}! Your profile is ready.`);
      } else {
        // Sign In
        if (firebaseEnabled && firebaseAuth) {
          const credential = await signInWithEmailAndPassword(firebaseAuth, email, password);
          if (credential.user) {
            const loggedUser: User = {
              uid: credential.user.uid,
              email: credential.user.email || email,
              displayName: credential.user.displayName || email.split("@")[0],
              isDemo: false,
            };
            setUser(loggedUser);
            await syncFromCloud(credential.user.uid);
          }
        } else {
          // Local sign in check
          const accountsStr = localStorage.getItem("shopai_accounts") || "[]";
          const accounts = JSON.parse(accountsStr);
          const matched = accounts.find(
            (a: any) => a.email.toLowerCase() === email.toLowerCase() && a.password === password
          );
          if (!matched) {
            throw new Error("Invalid email or password. Feel free to Create Account to make a local test profile!");
          }
          const loggedUser: User = {
            uid: matched.uid,
            email: matched.email,
            displayName: matched.displayName,
            isDemo: true,
          };
          localStorage.setItem("shopai_mock_user", JSON.stringify(loggedUser));
          setUser(loggedUser);
          
          // Load wishlist
          const savedWish = localStorage.getItem(`shopai_wishlist_${matched.uid}`);
          if (savedWish) {
            setSavedProducts(JSON.parse(savedWish));
          }
          // Load custom products
          const localCustomsStr = localStorage.getItem(`shopai_customs_${matched.uid}`);
          if (localCustomsStr) {
            const localCustoms = JSON.parse(localCustomsStr);
            setProducts((prev) => {
              const updated = [...prev];
              localCustoms.forEach((c: Product) => {
                if (!updated.some((p) => p.id === c.id)) {
                  updated.push(c);
                }
              });
              return updated;
            });
          }
        }
        triggerNotification(`Welcome back, ${name || email.split("@")[0]}!`);
      }

      setAuthModalOpen(false);
      setAuthEmail("");
      setAuthPassword("");
      setAuthName("");
    } catch (error: any) {
      console.error("Auth submit error:", error);
      setAuthError(error.message || "An authentication error occurred.");
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    setAuthDropdownOpen(false);
    try {
      if (firebaseEnabled && firebaseAuth) {
        await firebaseSignOut(firebaseAuth);
      } else {
        localStorage.removeItem("shopai_mock_user");
      }
      setUser(null);
      setSavedProducts([]);
      // Reset catalog to initial list
      setProducts(INITIAL_PRODUCTS);
      triggerNotification("Sign out successful.");
    } catch (error) {
      console.error("Sign out error:", error);
    }
  };

  const handleDemoBypass = () => {
    const demoUser: User = {
      uid: "guest_sandbox_user",
      email: "guest@shopai.internal",
      displayName: "Guest Sandbox",
      isDemo: true,
    };
    localStorage.setItem("shopai_mock_user", JSON.stringify(demoUser));
    setUser(demoUser);

    const savedWish = localStorage.getItem("shopai_wishlist_guest_sandbox_user");
    if (savedWish) {
      setSavedProducts(JSON.parse(savedWish));
    }
    const localCustomsStr = localStorage.getItem("shopai_customs_guest_sandbox_user");
    if (localCustomsStr) {
      const localCustoms = JSON.parse(localCustomsStr);
      setProducts((prev) => {
        const updated = [...prev];
        localCustoms.forEach((c: Product) => {
          if (!updated.some((p) => p.id === c.id)) {
            updated.push(c);
          }
        });
        return updated;
      });
    }

    setAuthModalOpen(false);
    triggerNotification("Logged in via Guest Local Sandbox!");
  };

  const triggerNotification = (text: string) => {
    setNotification(text);
    setTimeout(() => {
      setNotification(null);
    }, 3000);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query) return;

    if (!textToSend) {
      setInputText("");
    }

    const userMsg: Message = {
      id: "msg_" + Date.now(),
      role: "user",
      content: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMsg].map((m) => ({
            role: m.role,
            content: m.content,
          })),
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to communicate with shopping assistant backend.");
      }

      const data = await response.json();

      let finalContent = data.reply || "";
      let parsedProducts: Product[] = [];

      // Extract product-data-json if present
      const jsonBlockRegex = /```product-data-json\s*([\s\S]*?)\s*```/gi;
      const match = jsonBlockRegex.exec(finalContent);
      if (match) {
        try {
          const jsonContent = match[1].trim();
          parsedProducts = JSON.parse(jsonContent);
          // Remove the JSON code block from rendering in standard markdown
          finalContent = finalContent.replace(jsonBlockRegex, "").trim();
        } catch (e) {
          console.error("Failed to parse product-data-json:", e);
        }
      }

      // Automatically register the found products in our global comparison catalog
      if (parsedProducts && parsedProducts.length > 0) {
        setProducts((prev) => {
          const updated = [...prev];
          parsedProducts.forEach((newProd) => {
            if (!updated.some((p) => p.id === newProd.id || p.name.toLowerCase() === newProd.name.toLowerCase())) {
              updated.push(newProd);
            }
          });
          return updated;
        });

        // Auto-switch tab to the category of the first searched product
        const firstCategory = parsedProducts[0].category;
        if (firstCategory && ["laptop", "mobile", "tv", "other"].includes(firstCategory)) {
          setActiveCategory(firstCategory as any);
        }

        triggerNotification(`Synchronized ${parsedProducts.length} new ${parsedProducts[0].category}(s) to comparison board!`);
      }

      const aiMsg: Message = {
        id: "ai_" + Date.now(),
        role: "assistant",
        content: finalContent,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        groundingMetadata: data.groundingMetadata,
        products: parsedProducts.length > 0 ? parsedProducts : undefined,
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (error: any) {
      console.error("Chat Error:", error);
      setMessages((prev) => [
        ...prev,
        {
          id: "error_" + Date.now(),
          role: "assistant",
          content: `⚠️ Sorry, I encountered an issue connecting to my product search databases: **${error.message}**. Please verify your API key configuration.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const selectPriority = (profileType: string) => {
    setSelectedPriority(profileType);
    let promptMsg = "";
    let systemExplanation = "";

    if (activeCategory === "laptop") {
      if (profileType === "coding") {
        promptMsg = "I prioritize coding performance. I compile code, run IDEs like VS Code/IntelliJ, and multitask with Docker or browser tabs. Which laptop under ₹60k fits best and why?";
        systemExplanation = `Excellent choice! When compiling code or running virtualization tasks (like Docker/WSL), CPU core speeds and RAM size are your absolute bottlenecks. 
- **Ram is King**: 16GB RAM is essential. 8GB will cause disk paging and freeze your IDE.
- **CPU Choice**: Ryzen 5 6600H on the Lenovo (or Ryzen 5 5600H on HP) offers multiple high-efficiency threads.
- **Our Recommendation**: The **Lenovo IdeaPad Gaming 3** offers the newest Ryzen 6000 Zen 3+ processor and DDR5 capability, though you should upgrade it to 16GB RAM for optimal multithreading. Alternatively, the **HP Victus** with 16GB RAM out of the box is fantastic.`;
      } else if (profileType === "gaming") {
        promptMsg = "I prioritize gaming performance. I want high FPS, smooth graphics, and full compatibility with AAA games under ₹60k. Recommend the best GPU option.";
        systemExplanation = `Awesome! For gaming, your GPU (Graphics Processing Unit) is the ultimate determinant of performance. 
- **GPU Tiering**: The **NVIDIA RTX 3050** has dedicated ray-tracing cores and is roughly **25% faster** than the RTX 2050 in synthetic benchmarks and raw game FPS.
- **Display Speed**: A high refresh rate display (144Hz) makes fast-paced games look exceptionally fluid.
- **Our Recommendation**: The **ASUS TUF Gaming F15** is the clear winner here. It packs a fully powered **RTX 3050** paired with a super-fluid 144Hz display and military-grade durability to handle thermal gaming stress.`;
      } else {
        promptMsg = "I need a balanced laptop. Explain how to get the best of both worlds (coding and gaming) under ₹60,000.";
        systemExplanation = `A balanced setup is highly intelligent. You get clean battery backup for coding on the go, plus dedicated power for evening gaming!
- **The Balance**: Look for AMD processors (which consume far less idle power than Intel) paired with discrete graphics.
- **Our Recommendation**: The **HP Victus 15** is the sweet-spot here. The Ryzen 5 5600H draws minimal battery during code development (lasting up to 5 hours), its design is clean and professional for workspaces, and the RTX 2050 graphics can still comfortably handle competitive games like Valorant, CS2, or GTA V at medium-high settings.`;
      }
    } else if (activeCategory === "mobile") {
      if (profileType === "coding") { // Map 'coding' label dynamically to 'Camera'
        promptMsg = "I prioritize camera quality. I take portrait photos, low-light night shots, and record videos. Which mobile fits best under ₹25,000?";
        systemExplanation = `Fantastic choice! For dynamic photography, optical image stabilization (OIS) and high sensor resolution are critical.
- **Sensor Count & Detail**: The **Redmi Note 13 Pro** leads with its ultra-crisp **200MP camera sensor** and OIS, capturing incredible digital crop details.
- **Real-world Colors**: The **Samsung Galaxy A35** excels in natural skin tones and post-processing.
- **Our Recommendation**: The **Redmi Note 13 Pro 5G** captures the best details under sunlight, while the **OnePlus Nord CE4** offers faster capture shutter times and Sony's LYT-600 sensor.`;
      } else if (profileType === "gaming") { // Performance
        promptMsg = "I prioritize gaming and multitasking on mobile. I want lag-free performance and high frame-rates under ₹25,000.";
        systemExplanation = `Superb! Mobile gaming requires high-efficiency cooling chips and modern 4nm processing.
- **Processor Tier**: The **OnePlus Nord CE4** features the high-performance **Snapdragon 7 Gen 3**, easily outperforming the Exynos 1380 on the Samsung.
- **Our Recommendation**: The **OnePlus Nord CE4** is the speed champion here. It has zero stutter and runs popular multiplayer titles like BGMI, Free Fire, and Genshin Impact seamlessly.`;
      } else { // Endurance
        promptMsg = "I prioritize battery life and ultra-fast charging. I hate waiting for my phone to charge under ₹25,000.";
        systemExplanation = `Got it! Slow charging is frustrating.
- **Fast Charge**: The **OnePlus Nord CE4** boasts a huge **5500mAh battery** paired with a blistering **100W SuperVOOC charger** in the box. It charges from 0 to 100% in under 30 minutes!
- **Our Recommendation**: The **OnePlus Nord CE4** wins here by a landslide. The Samsung and Redmi offer 25W and 67W respectively, which are good, but cannot compete with 100W speeds.`;
      }
    } else { // TV
      if (profileType === "coding") { // Cinema Display
        promptMsg = "I prioritize visual display and cinema-like colors on a Smart TV. What fits best under ₹30,000?";
        systemExplanation = `Ah, a movie lover! For a cinematic vibe, Dolby Vision and HDR10 support are key.
- **Contrast & Colors**: The **Xiaomi Smart TV X Series** features premium 4K resolution with native Dolby Vision, yielding magnificent depth.
- **Brand Upscaling**: The **Samsung Crystal 4K Vivid** offers the best SD-to-4K content upscaling using its Crystal Processor.
- **Our Recommendation**: Pick the **Xiaomi Smart TV X Series (43\")** for its native Dolby Vision integration. It represents unparalleled value for cinema viewing.`;
      } else if (profileType === "gaming") { // Audio
        promptMsg = "I want a Smart TV with the loudest, clearest, and most immersive sound experience under ₹30,000.";
        systemExplanation = `Understood! Sound completes the picture.
- **Speaker Wattage**: The **Xiaomi Smart TV X Series** leads with **30W speaker output** supporting Dolby Audio, DTS-HD, and DTS:X.
- **Sound Tracking**: The **Samsung Crystal 4K** offers **Object Tracking Sound (OTS Lite)** which makes audio move with action.
- **Our Recommendation**: The **Xiaomi Smart TV X Series** is the clear loudness winner here, though the Samsung has slightly cleaner spatial effects.`;
      } else { // Smart OS / Connectivity
        promptMsg = "I prioritize smooth UI software and maximum connectivity for gaming consoles on a Smart TV.";
        systemExplanation = `Excellent! A laggy smart TV UI ruins the experience.
- **Software Interface**: Google TV (on Xiaomi) offers a highly fluid modern home page. Samsung's Tizen is extremely fast and integrates with smart home tech.
- **Our Recommendation**: The **Xiaomi Smart TV X Series** or **Samsung Crystal 4K** both have excellent modern operating systems and 3 HDMI ports to support setups like PS5, Apple TV, and soundbars.`;
      }
    }

    setMessages((prev) => [
      ...prev,
      {
        id: "usr_" + Date.now(),
        role: "user",
        content: promptMsg,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
      {
        id: "expl_" + Date.now(),
        role: "assistant",
        content: systemExplanation,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      }
    ]);

    triggerNotification(`Priority profile updated!`);
    setActiveTab("scorer");
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: "welcome",
        role: "assistant",
        content: "Hi! I've cleared our chat history. Let me know what laptops, mobiles, televisions, or specifications you'd like to compare and analyze!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  const addCustomProduct = async (newProduct: Product) => {
    setProducts((prev) => [...prev, newProduct]);
    triggerNotification(`Successfully added ${newProduct.name} to our visual compare board!`);

    if (user) {
      if (firebaseEnabled && firebaseDb) {
        try {
          const docRef = doc(firebaseDb, "users", user.uid, "custom_products", newProduct.id);
          await setDoc(docRef, newProduct);
        } catch (e) {
          handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/custom_products/${newProduct.id}`);
        }
      } else {
        const localCustomsStr = localStorage.getItem(`shopai_customs_${user.uid}`) || "[]";
        const localCustoms = JSON.parse(localCustomsStr);
        if (!localCustoms.some((p: any) => p.id === newProduct.id)) {
          localCustoms.push(newProduct);
          localStorage.setItem(`shopai_customs_${user.uid}`, JSON.stringify(localCustoms));
        }
      }
    }
  };

  const removeProduct = async (id: string) => {
    const pName = products.find(p => p.id === id)?.name || "product";
    setProducts((prev) => prev.filter((p) => p.id !== id));
    triggerNotification(`Removed ${pName} from workspace.`);

    if (user) {
      if (firebaseEnabled && firebaseDb) {
        try {
          const { deleteDoc } = await import("firebase/firestore");
          const docRef = doc(firebaseDb, "users", user.uid, "custom_products", id);
          await deleteDoc(docRef);
        } catch (e) {
          handleFirestoreError(e, OperationType.DELETE, `users/${user.uid}/custom_products/${id}`);
        }
      } else {
        const localCustomsStr = localStorage.getItem(`shopai_customs_${user.uid}`) || "[]";
        let localCustoms = JSON.parse(localCustomsStr);
        localCustoms = localCustoms.filter((p: any) => p.id !== id);
        localStorage.setItem(`shopai_customs_${user.uid}`, JSON.stringify(localCustoms));
      }
    }
  };

  const handleSuggestionClick = (query: string) => {
    handleSendMessage(query);
  };

  const toggleSaveProduct = async (id: string) => {
    let updatedWishlist: string[] = [];
    if (savedProducts.includes(id)) {
      updatedWishlist = savedProducts.filter(item => item !== id);
      setSavedProducts(updatedWishlist);
      triggerNotification("Removed from wishlist.");
    } else {
      updatedWishlist = [...savedProducts, id];
      setSavedProducts(updatedWishlist);
      triggerNotification("Added to wishlist! ❤️");
    }

    if (user) {
      if (firebaseEnabled && firebaseDb) {
        try {
          const docRef = doc(firebaseDb, "users", user.uid, "wishlist", "main");
          await setDoc(docRef, { saved: updatedWishlist });
        } catch (e) {
          handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/wishlist/main`);
        }
      } else {
        localStorage.setItem(`shopai_wishlist_${user.uid}`, JSON.stringify(updatedWishlist));
      }
    }
  };

  const parsePrice = (priceStr: string): number => {
    const cleanStr = priceStr.replace(/[^0-9]/g, "");
    return parseInt(cleanStr, 10) || 0;
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(val);
  };

  // Filter based on active category AND search query
  const filteredProducts = products.filter(p => {
    const categoryMatches = p.category === activeCategory;
    const searchMatches =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      Object.values(p.specs).some(val => val.toLowerCase().includes(searchQuery.toLowerCase()));
    return categoryMatches && searchMatches;
  });

  const categoryConfig = CATEGORIES.find((c) => c.id === activeCategory) || CATEGORIES[0];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans" id="app-root">
      
      {/* Flipkart / Amazon Inspired Top Navigation Bar */}
      <header className="bg-slate-900 text-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-3 flex flex-col sm:flex-row items-center justify-between gap-3">
          
          {/* Logo Brand */}
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-amber-500 rounded-xl flex items-center justify-center shadow-lg shadow-amber-500/20">
              <ShoppingCart className="w-5 h-5 text-slate-950 stroke-[2.5]" />
            </div>
            <div>
              <span className="font-extrabold text-xl tracking-tight text-white flex items-center gap-1">
                ShopAI <span className="text-amber-400 text-xs font-semibold bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">PORTAL</span>
              </span>
              <p className="text-[9px] text-slate-400 font-medium">Flipkart & Amazon Live Specs Crawler</p>
            </div>
          </div>

          {/* E-commerce Search Bar */}
          <div className="flex-1 max-w-lg w-full relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
              <Search className="w-4 h-4 text-slate-400" />
            </div>
            <input
              type="text"
              placeholder={`Search in ${categoryConfig.label} (e.g. AMOLED, 4K, RTX, OIS, 16GB)...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-800/80 hover:bg-slate-800 focus:bg-white text-slate-100 focus:text-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl text-xs outline-none transition-all placeholder-slate-400"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-100 text-xs"
              >
                Clear
              </button>
            )}
          </div>

          {/* Wishlist & Auth Status */}
          <div className="flex items-center gap-4 text-xs">
            <div className="hidden lg:flex items-center gap-1.5 text-slate-300">
              <Truck className="w-4 h-4 text-amber-400" />
              <span>Free Express Delivery across India</span>
            </div>
            <div className="flex items-center gap-1 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg shrink-0">
              <Heart className="w-4 h-4 text-red-400 fill-red-400" />
              <span className="font-bold text-amber-400 font-mono">{savedProducts.length}</span>
              <span className="text-slate-300 hidden sm:inline ml-1">Wishlist</span>
            </div>

            {/* User Dropdown or Login Button */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setAuthDropdownOpen(!authDropdownOpen)}
                  className="flex items-center gap-2 bg-slate-800 border border-slate-700 hover:border-amber-400 px-2.5 py-1.5 rounded-lg transition cursor-pointer"
                >
                  <div className="w-5 h-5 bg-gradient-to-tr from-amber-400 to-amber-600 rounded-full flex items-center justify-center text-slate-950 font-black text-[10px] uppercase shrink-0">
                    {user.displayName.slice(0, 2)}
                  </div>
                  <span className="text-slate-200 font-bold max-w-[80px] truncate hidden md:inline">
                    {user.displayName}
                  </span>
                  <ChevronDown className="w-3 h-3 text-slate-400 shrink-0" />
                </button>

                {authDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl border border-slate-200 shadow-xl py-2 z-50 text-slate-700">
                    <div className="px-3.5 py-2 border-b border-slate-100">
                      <span className="block font-bold text-slate-900 truncate">{user.displayName}</span>
                      <span className="block text-[10px] text-slate-500 truncate">{user.email}</span>
                      <span className="inline-flex items-center gap-1 mt-1 text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-700 uppercase">
                        {user.isDemo ? "Local Sandbox Account" : "Cloud Sync Live"}
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        setAuthDropdownOpen(false);
                        triggerNotification("Credentials Guide: Run 'set_up_firebase' to connect live!");
                      }}
                      className="w-full text-left px-3.5 py-2 text-xs hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Shield className="w-3.5 h-3.5 text-slate-400" />
                      <span>Production DB Settings</span>
                    </button>
                    <button
                      onClick={handleSignOut}
                      className="w-full text-left px-3.5 py-2 text-xs hover:bg-red-50 text-red-600 font-bold border-t border-slate-100 flex items-center gap-2"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-red-500" />
                      <span>Log Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => {
                  setAuthMode("login");
                  setAuthModalOpen(true);
                  setAuthError(null);
                }}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3.5 py-1.5 rounded-lg transition text-xs shadow-md shadow-amber-500/10 cursor-pointer shrink-0"
              >
                Log In
              </button>
            )}
          </div>

        </div>

        {/* Categories Tab Bar */}
        <div className="bg-slate-800 border-t border-slate-700 py-2 overflow-x-auto">
          <div className="max-w-7xl mx-auto px-4 md:px-6 flex gap-4 md:gap-6 text-xs font-bold text-slate-300 shrink-0 whitespace-nowrap">
            <span className="text-amber-400 flex items-center gap-1 cursor-pointer hover:text-white"><Zap className="w-3.5 h-3.5 animate-pulse" /> Super Deals of the Day</span>
            
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setActiveCategory(cat.id);
                  setSelectedPriority(null);
                  triggerNotification(`Switched database to ${cat.label}`);
                }}
                className={`transition ${activeCategory === cat.id ? "text-amber-400 font-extrabold border-b-2 border-amber-400 pb-0.5" : "hover:text-amber-300"}`}
              >
                {cat.icon} {cat.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Floating Notifications */}
      {notification && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 text-white text-xs px-4 py-3 rounded-xl border border-slate-700 shadow-xl flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span className="font-medium">{notification}</span>
        </div>
      )}

      {/* Flipkart Banner Offer & Priority Assessment Form */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-800 to-slate-900 text-white py-6 px-4 md:px-8 border-b border-indigo-950">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          
          {/* Left: Text and Banner */}
          <div className="lg:col-span-7 space-y-3">
            <div className="inline-flex items-center gap-1.5 bg-amber-400 text-slate-950 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
              <Percent className="w-3.5 h-3.5" /> Best Selling Category
            </div>
            <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              Compare the Best <span className="text-amber-400">{categoryConfig.label}</span> under <span className="text-amber-400">{formatCurrency(categoryConfig.defaultBudget)}</span>
            </h2>
            <p className="text-xs text-indigo-100 max-w-xl leading-relaxed">
              We've scanned top databases across Flipkart and Amazon. Click below to load custom shopping filters or configure your spec requirements!
            </p>
          </div>

          {/* Right: Category Specific Priority Buttons */}
          <div className="lg:col-span-5 bg-white/10 backdrop-blur-md border border-white/10 p-4 rounded-2xl space-y-3">
            <span className="text-xs font-bold text-amber-300 uppercase tracking-widest block">Choose Assessment Profile:</span>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => selectPriority("coding")}
                className={`py-2 px-1 rounded-xl text-[11px] font-bold transition-all flex flex-col items-center justify-center gap-1 border ${
                  selectedPriority === "coding"
                    ? "bg-amber-400 text-slate-950 border-amber-500 scale-[1.03] shadow-md shadow-amber-400/20"
                    : "bg-white/5 text-white border-white/10 hover:bg-white/10"
                }`}
              >
                {activeCategory === "laptop" && <Cpu className="w-4 h-4 text-amber-300" />}
                {activeCategory === "mobile" && <Smartphone className="w-4 h-4 text-amber-300" />}
                {activeCategory === "tv" && <Tv className="w-4 h-4 text-amber-300" />}
                <span>
                  {activeCategory === "laptop" && "💻 Coding"}
                  {activeCategory === "mobile" && "📸 Camera"}
                  {activeCategory === "tv" && "🍿 Cinema"}
                </span>
              </button>
              
              <button
                onClick={() => selectPriority("gaming")}
                className={`py-2 px-1 rounded-xl text-[11px] font-bold transition-all flex flex-col items-center justify-center gap-1 border ${
                  selectedPriority === "gaming"
                    ? "bg-amber-400 text-slate-950 border-amber-500 scale-[1.03] shadow-md shadow-amber-400/20"
                    : "bg-white/5 text-white border-white/10 hover:bg-white/10"
                }`}
              >
                <Zap className="w-4 h-4 text-amber-300" />
                <span>
                  {activeCategory === "laptop" && "🎮 Gaming"}
                  {activeCategory === "mobile" && "⚡ Performance"}
                  {activeCategory === "tv" && "🔊 Audio Stage"}
                </span>
              </button>

              <button
                onClick={() => selectPriority("balanced")}
                className={`py-2 px-1 rounded-xl text-[11px] font-bold transition-all flex flex-col items-center justify-center gap-1 border ${
                  selectedPriority === "balanced"
                    ? "bg-amber-400 text-slate-950 border-amber-500 scale-[1.03] shadow-md shadow-amber-400/20"
                    : "bg-white/5 text-white border-white/10 hover:bg-white/10"
                }`}
              >
                <Star className="w-4 h-4 text-amber-300" />
                <span>
                  {activeCategory === "laptop" && "⚖️ Balanced"}
                  {activeCategory === "mobile" && "🔋 Endurance"}
                  {activeCategory === "tv" && "⚙️ Smart OS"}
                </span>
              </button>
            </div>
            <p className="text-[10px] text-indigo-200 text-center">
              Updates weights and triggers AI advice!
            </p>
          </div>

        </div>
      </div>

      {/* Main E-commerce Layout Grid */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* LEFT COLUMN: Offers & AI Chat */}
        <section className="lg:col-span-5 flex flex-col gap-6">
          
          {/* Flipkart-Style Offers & Filters Bar */}
          <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs space-y-3">
            <span className="font-bold text-xs text-slate-700 flex items-center gap-1.5 border-b border-slate-100 pb-2">
              <Tag className="w-4 h-4 text-amber-500" /> E-Commerce Promotional Offers
            </span>
            <div className="space-y-2 text-[11px]">
              <div className="flex gap-2 items-start text-slate-600">
                <span className="bg-emerald-50 text-emerald-700 font-bold px-1 rounded text-[9px] border border-emerald-100 shrink-0">BANK OFFER</span>
                <span>Get 10% instant discount up to ₹1,500 on all major credit card EMI plans.</span>
              </div>
              <div className="flex gap-2 items-start text-slate-600">
                <span className="bg-emerald-50 text-emerald-700 font-bold px-1 rounded text-[9px] border border-emerald-100 shrink-0">EXCHANGE</span>
                <span>Exchange your old smartphone, TV, or laptop and secure up to ₹10,000 extra trade value.</span>
              </div>
            </div>
          </div>

          {/* AI Interactive Chat Console */}
          <div className="flex flex-col bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden h-[480px]">
            {/* Panel Header */}
            <div className="px-4 py-3 bg-slate-50 border-b border-slate-150 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-indigo-600" />
                <span className="font-bold text-xs text-slate-700 uppercase tracking-wider">ShopAI Expert Grounding Chat</span>
              </div>
              <span className="text-[10px] font-bold text-emerald-600 flex items-center gap-1">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"></span> Live Grounding
              </span>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4" id="chat-scroller">
              {messages.map((msg) => {
                const isAi = msg.role === "assistant";
                return (
                  <div key={msg.id} className={`flex ${isAi ? "justify-start" : "justify-end"} gap-2.5 items-start`}>
                    {isAi && (
                      <div className="w-7 h-7 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center font-extrabold text-[10px] shrink-0">
                        AI
                      </div>
                    )}
                    <div className="flex flex-col gap-1 max-w-[85%]">
                      <div
                        className={`px-3.5 py-2.5 rounded-2xl text-[12px] leading-relaxed shadow-xs ${
                          isAi
                            ? "bg-slate-50 text-slate-700 border border-slate-200 rounded-tl-none"
                            : "bg-indigo-600 text-white rounded-tr-none"
                        }`}
                      >
                        <div className="prose prose-sm max-w-none prose-slate text-[11.5px]">
                          <ReactMarkdown>{msg.content}</ReactMarkdown>
                        </div>

                        {/* Display Grounding Citations if available */}
                        {isAi && msg.groundingMetadata?.groundingChunks && msg.groundingMetadata.groundingChunks.length > 0 && (
                          <div className="mt-3 pt-2 border-t border-slate-200/80">
                            <span className="text-[9px] font-bold text-slate-400 block mb-1 uppercase tracking-wider">Verified Sources:</span>
                            <div className="flex flex-wrap gap-1">
                              {msg.groundingMetadata.groundingChunks.map((chunk, idx) => {
                                if (!chunk.web) return null;
                                return (
                                  <a
                                    key={idx}
                                    href={chunk.web.uri}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-1 bg-white hover:bg-slate-100 text-indigo-600 hover:text-indigo-700 border border-slate-200 px-1.5 py-0.5 rounded text-[9px] font-medium transition"
                                  >
                                    <span>{chunk.web.title || "Source"}</span>
                                    <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                                  </a>
                                );
                              })}
                            </div>
                          </div>
                        )}

                        {/* Render parsed products list inside the message bubble */}
                        {isAi && msg.products && msg.products.length > 0 && (
                          <div className="mt-3 pt-3 border-t border-slate-200/80 space-y-2">
                            <span className="text-[10px] font-bold text-slate-500 block uppercase tracking-wider">Matched Live Specs ({msg.products.length}):</span>
                            <div className="flex flex-col gap-2">
                              {msg.products.map((prod) => {
                                const isAlreadyAdded = products.some((p) => p.id === prod.id || p.name.toLowerCase() === prod.name.toLowerCase());
                                return (
                                  <div key={prod.id} className="bg-white border border-slate-200 hover:border-amber-400 rounded-xl p-2.5 flex flex-col justify-between shadow-2xs transition">
                                    <div className="flex justify-between items-start gap-1">
                                      <div>
                                        <div className="flex items-center gap-1.5 flex-wrap">
                                          <span className="text-[8px] font-bold bg-indigo-50 text-indigo-700 px-1 py-0.5 rounded uppercase font-mono">
                                            {prod.category === "tv" ? "Smart TV" : prod.category}
                                          </span>
                                          <span className="font-extrabold text-[11px] text-slate-800 line-clamp-1">{prod.name}</span>
                                        </div>
                                        <div className="flex items-baseline gap-1 mt-0.5">
                                          <span className="text-[11px] font-bold text-slate-900">{prod.price}</span>
                                          <span className="text-[8px] text-slate-400 line-through">
                                            {formatCurrency(Math.round(parsePrice(prod.price) * 1.25))}
                                          </span>
                                        </div>
                                      </div>
                                      <button
                                        onClick={() => {
                                          if (isAlreadyAdded) {
                                            removeProduct(prod.id);
                                          } else {
                                            addCustomProduct(prod);
                                            setActiveCategory(prod.category as any);
                                          }
                                        }}
                                        className={`px-2 py-1 text-[9px] font-bold rounded-lg border flex items-center gap-0.5 transition cursor-pointer shrink-0 ${
                                          isAlreadyAdded 
                                            ? "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100"
                                            : "bg-indigo-600 text-white border-indigo-600 hover:bg-indigo-750"
                                        }`}
                                      >
                                        {isAlreadyAdded ? (
                                          <>
                                            <Check className="w-2.5 h-2.5" /> Checked
                                          </>
                                        ) : (
                                          "Add to Board"
                                        )}
                                      </button>
                                    </div>
                                    <div className="mt-1.5 grid grid-cols-2 gap-x-2 gap-y-0.5 text-[9px] text-slate-500 bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                                      {Object.entries(prod.specs).slice(0, 4).map(([key, value]) => (
                                        <div key={key} className="flex gap-1 items-baseline truncate">
                                          <span className="font-medium text-slate-400 shrink-0">{key}:</span>
                                          <span className="text-slate-600 font-semibold truncate">{value}</span>
                                        </div>
                                      ))}
                                    </div>
                                    {prod.pros && prod.pros.length > 0 && (
                                      <div className="mt-1 flex gap-1 items-center text-[9px] text-emerald-650 font-medium">
                                        <ThumbsUp className="w-2.5 h-2.5 text-emerald-500 shrink-0" />
                                        <span className="line-clamp-1">{prod.pros[0]}</span>
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                      <span className={`text-[9px] text-slate-400 px-1 ${!isAi ? "text-right" : ""}`}>
                        {msg.timestamp}
                      </span>
                    </div>
                  </div>
                );
              })}

              {isLoading && (
                <div className="flex justify-start gap-2.5 items-start animate-pulse">
                  <div className="w-7 h-7 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs shrink-0">
                    AI
                  </div>
                  <div className="bg-slate-50 border border-slate-200 px-3.5 py-2.5 rounded-2xl rounded-tl-none max-w-[80%] flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                    <span className="text-[10px] text-slate-400 ml-1.5 font-medium">Scanning e-commerce web...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Suggestion Prompts */}
            <div className="px-3 py-1.5 bg-slate-50 border-t border-slate-150 overflow-x-auto flex gap-1.5 no-scrollbar scroll-smooth">
              {activeCategory === "laptop" && (
                <>
                  <button
                    onClick={() => handleSuggestionClick("Compare Ryzen 5 5600H vs i5-11400H for compiling code.")}
                    className="shrink-0 px-2 py-0.5 bg-white hover:bg-indigo-50 text-slate-600 hover:text-indigo-700 text-[10px] rounded-full border border-slate-200 hover:border-indigo-200 transition font-medium"
                  >
                    💻 CPU Compile Performance
                  </button>
                  <button
                    onClick={() => handleSuggestionClick("Compare HP Victus vs Asus TUF graphics processing and cooling.")}
                    className="shrink-0 px-2 py-0.5 bg-white hover:bg-indigo-50 text-slate-600 hover:text-indigo-700 text-[10px] rounded-full border border-slate-200 hover:border-indigo-200 transition font-medium"
                  >
                    🎮 Cooling & Graphics
                  </button>
                </>
              )}
              {activeCategory === "mobile" && (
                <>
                  <button
                    onClick={() => handleSuggestionClick("Compare camera specs of Redmi Note 13 Pro (200MP) vs Samsung A35.")}
                    className="shrink-0 px-2 py-0.5 bg-white hover:bg-indigo-50 text-slate-600 hover:text-indigo-700 text-[10px] rounded-full border border-slate-200 hover:border-indigo-200 transition font-medium"
                  >
                    📸 200MP vs 50MP Cameras
                  </button>
                  <button
                    onClick={() => handleSuggestionClick("Which phone under ₹25k has the fastest charging battery?")}
                    className="shrink-0 px-2 py-0.5 bg-white hover:bg-indigo-50 text-slate-600 hover:text-indigo-700 text-[10px] rounded-full border border-slate-200 hover:border-indigo-200 transition font-medium"
                  >
                    ⚡ Fast Charge Options
                  </button>
                </>
              )}
              {activeCategory === "tv" && (
                <>
                  <button
                    onClick={() => handleSuggestionClick("What is Dolby Vision display tech and does Xiaomi TV support it?")}
                    className="shrink-0 px-2 py-0.5 bg-white hover:bg-indigo-50 text-slate-600 hover:text-indigo-700 text-[10px] rounded-full border border-slate-200 hover:border-indigo-200 transition font-medium"
                  >
                    📺 Dolby Vision Explained
                  </button>
                  <button
                    onClick={() => handleSuggestionClick("Compare sound outputs: Xiaomi 30W vs Samsung Crystal TV.")}
                    className="shrink-0 px-2 py-0.5 bg-white hover:bg-indigo-50 text-slate-600 hover:text-indigo-700 text-[10px] rounded-full border border-slate-200 hover:border-indigo-200 transition font-medium"
                  >
                    🔊 30W Audio vs 20W OTS
                  </button>
                </>
              )}
              <button
                onClick={() => handleClearChat()}
                className="shrink-0 px-2.5 py-0.5 bg-slate-100 hover:bg-red-50 text-slate-500 hover:text-red-600 text-[10px] rounded-full border border-slate-200 hover:border-red-200 transition font-medium flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" /> Reset Chat
              </button>
            </div>

            {/* Chat Input */}
            <div className="p-2.5 bg-white border-t border-slate-150">
              <div className="relative flex items-center">
                <input
                  type="text"
                  placeholder={`Ask ShopAI (e.g. 'Compare ${categoryConfig.label} options' or search specific specs)...`}
                  className="w-full pl-3 pr-10 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all text-xs"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                  id="input-chat"
                />
                <button
                  onClick={() => handleSendMessage()}
                  disabled={isLoading || !inputText.trim()}
                  className="absolute right-1.5 w-6 h-6 bg-indigo-600 text-white rounded-lg flex items-center justify-center hover:bg-indigo-700 transition disabled:opacity-40 disabled:hover:bg-indigo-600 cursor-pointer"
                  id="btn-send"
                >
                  <Send className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

        </section>

        {/* RIGHT COLUMN: Interactive Workspace */}
        <section className="lg:col-span-7 flex flex-col bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden h-[calc(100vh-140px)] min-h-[500px]">
          
          {/* Workspace Tabs Header */}
          <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 flex items-center justify-between shrink-0">
            <div className="flex gap-1 bg-slate-200/60 p-1 rounded-xl">
              <button
                onClick={() => setActiveTab("compare")}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                  activeTab === "compare"
                    ? "bg-white text-slate-800 shadow-xs"
                    : "text-slate-500 hover:text-slate-800"
                }`}
                id="tab-compare"
              >
                {activeCategory === "laptop" && <Laptop className="w-3.5 h-3.5" />}
                {activeCategory === "mobile" && <Smartphone className="w-3.5 h-3.5" />}
                {activeCategory === "tv" && <Tv className="w-3.5 h-3.5" />}
                <span>Specs Comparison Board ({filteredProducts.length})</span>
              </button>
              <button
                onClick={() => setActiveTab("scorer")}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                  activeTab === "scorer"
                    ? "bg-white text-slate-800 shadow-xs"
                    : "text-slate-500 hover:text-slate-800"
                }`}
                id="tab-scorer"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                Smart Priorities Scorer
              </button>
            </div>

            <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-slate-400 font-medium">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
              <span>Real-time Specs Syncing</span>
            </div>
          </div>

          {/* Catalog & Table Container */}
          <div className="flex-1 overflow-y-auto p-4 md:p-6" id="workspace-container">
            {activeTab === "compare" ? (
              <div className="space-y-6">
                
                {/* Product Catalog Cards */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-xs text-slate-700 uppercase tracking-wider block">
                      Live {categoryConfig.label} Catalog
                    </span>
                    {searchQuery && (
                      <span className="text-[10px] text-indigo-600 font-semibold">
                        Filtered {filteredProducts.length} of {products.filter(p => p.category === activeCategory).length} items
                      </span>
                    )}
                  </div>
                  
                  {filteredProducts.length === 0 ? (
                    <div className="text-center py-6 bg-slate-50 border border-dashed border-slate-200 rounded-xl">
                      <p className="text-slate-400 text-xs">No matching {categoryConfig.label} found.</p>
                      <button
                        onClick={() => setSearchQuery("")}
                        className="text-xs text-indigo-600 font-bold mt-1.5 hover:underline"
                      >
                        Reset Search Filters
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {filteredProducts.map((product) => {
                        const isSaved = savedProducts.includes(product.id);
                        const origPrice = parsePrice(product.price);
                        return (
                          <div
                            key={product.id}
                            className="bg-white border border-slate-200 hover:border-amber-400 rounded-xl p-4 flex flex-col justify-between shadow-xs hover:shadow-md transition relative group"
                          >
                            {/* Wishlist Heart */}
                            <button
                              onClick={() => toggleSaveProduct(product.id)}
                              className="absolute top-2.5 right-2.5 text-slate-400 hover:text-red-500 transition-all scale-100 active:scale-90"
                              title="Save to Wishlist"
                            >
                              <Heart className={`w-4 h-4 ${isSaved ? "fill-red-500 text-red-500" : ""}`} />
                            </button>

                            {/* Top Tags */}
                            <div className="mb-2 flex items-center gap-1 flex-wrap">
                              {product.rating === 5 ? (
                                <span className="bg-amber-100 text-amber-800 text-[8px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider">
                                  BEST SELLER
                                </span>
                              ) : (
                                <span className="bg-slate-100 text-slate-700 text-[8px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider">
                                  EXPERT RECOMMEND
                                </span>
                              )}
                              <span className="bg-emerald-50 text-emerald-700 text-[8px] font-medium px-1 rounded flex items-center gap-0.5">
                                <Truck className="w-2.5 h-2.5" /> Fast
                              </span>
                            </div>

                            {/* Details */}
                            <div className="space-y-1">
                              <h4 className="font-bold text-xs text-slate-800 line-clamp-1 group-hover:text-indigo-600 transition">
                                {product.name}
                              </h4>
                              <div className="flex items-center gap-1.5">
                                <div className="flex">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={`w-3 h-3 ${
                                        star <= product.rating ? "fill-amber-400 text-amber-400" : "text-slate-200"
                                      }`}
                                    />
                                  ))}
                                </div>
                                <span className="text-[10px] text-slate-400 font-semibold">({product.rating}.0)</span>
                              </div>

                              {/* Price element like Flipkart */}
                              <div className="pt-1 flex items-baseline gap-1">
                                <span className="text-slate-900 font-extrabold text-sm">{product.price}</span>
                                <span className="text-[9px] text-slate-400 line-through">
                                  {formatCurrency(Math.round(origPrice * 1.25))}
                                </span>
                                <span className="text-[9px] text-emerald-600 font-bold font-mono">20% OFF</span>
                              </div>
                            </div>

                            {/* Dynamic Specifications list */}
                            <div className="border-t border-slate-100 my-2 pt-2 space-y-1 text-[10px] text-slate-600">
                              {Object.entries(product.specs).slice(0, 3).map(([key, val]) => (
                                <div key={key} className="flex items-center gap-1.5">
                                  <span className="text-slate-400 font-medium shrink-0">{key}:</span>
                                  <span className="font-semibold text-slate-700 line-clamp-1">{val}</span>
                                </div>
                              ))}
                            </div>

                            {/* Actions */}
                            <div className="pt-2">
                              <button
                                onClick={() => handleSuggestionClick(`Recommend why I should pick ${product.name} for my needs.`)}
                                className="w-full py-1 bg-slate-50 hover:bg-indigo-50 border border-slate-200 text-slate-700 hover:text-indigo-700 text-[10px] font-bold rounded-lg transition text-center"
                              >
                                Analyze Specs
                              </button>
                            </div>

                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div className="border-t border-slate-200 pt-4">
                  <ComparisonMatrix
                    products={products.filter((p) => p.category === activeCategory)}
                    activeCategory={activeCategory}
                    specKeys={categoryConfig.specKeys}
                    onAddProduct={addCustomProduct}
                    onRemoveProduct={removeProduct}
                  />
                </div>

              </div>
            ) : (
              <BudgetMatcher
                products={products.filter((p) => p.category === activeCategory)}
                activeCategory={activeCategory}
                sliderLabels={categoryConfig.sliderLabels}
                defaultBudget={categoryConfig.defaultBudget}
              />
            )}
          </div>
        </section>

      </div>

      {/* Dynamic Spec Explanations Footer based on Active Category */}
      <section className="bg-slate-100 border-t border-slate-200 py-6 px-4 md:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-600">
          
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              {activeCategory === "laptop" && <Cpu className="w-4 h-4 text-indigo-500" />}
              {activeCategory === "mobile" && <Smartphone className="w-4 h-4 text-indigo-500" />}
              {activeCategory === "tv" && <Tv className="w-4 h-4 text-indigo-500" />}
              <span>{activeCategory === "laptop" ? "Processor & Memory" : activeCategory === "mobile" ? "Mobile SoC & Power" : "Display Quality"}</span>
            </div>
            <p className="leading-relaxed text-[11px]">
              {activeCategory === "laptop" && "Compilers and heavy scripts are heavily multi-threaded. An H-series CPU is required to compile complex files fast. 16GB RAM is essential to run Docker pools lag-free."}
              {activeCategory === "mobile" && "A smartphone processor (SoC) dictates daily fluid multitasking and heavy gaming load times. A 4nm Snapdragon SoC offers elite power efficiency."}
              {activeCategory === "tv" && "4K UHD with Dolby Vision or HDR10+ enhances dynamic range. Crystal processors upscale SD content seamlessly into vivid visuals."}
            </p>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <Zap className="w-4 h-4 text-amber-500 animate-pulse" />
              <span>{activeCategory === "laptop" ? "Graphics/GPU Power" : activeCategory === "mobile" ? "Camera Sensors" : "Audio Stage"}</span>
            </div>
            <p className="leading-relaxed text-[11px]">
              {activeCategory === "laptop" && "Gaming requires dedicated RTX cards with DLSS technology to reconstruct frames, whereas integrated chipsets will bottleneck gaming to low FPS settings."}
              {activeCategory === "mobile" && "Large megapixel count (such as 200MP) paired with Optical Image Stabilization (OIS) produces crisp, high-resolution crop details in low-light environments."}
              {activeCategory === "tv" && "Standard TVs offer basic 20W sound output. Select models with 30W speaker output or spatial audio like OTS to make sounds track visually moving objects."}
            </p>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <HelpCircle className="w-4 h-4 text-indigo-500" />
              <span>Ask ShopAI Anything!</span>
            </div>
            <p className="leading-relaxed text-[11px]">
              {activeCategory === "laptop" && "Ask: 'Find cheapest laptop with RTX 3050 graphics' or 'Recommend ASUS TUF vs HP Victus for developer compilation speed.'"}
              {activeCategory === "mobile" && "Ask: 'Which mobile phone has Snapdragon 7 Gen 3 and 100W SuperVOOC charge?' or 'Recommend Samsung Galaxy A35 vs Redmi Note 13 Pro.'"}
              {activeCategory === "tv" && "Ask: 'Compare Xiaomi 43\" Dolby Vision with Samsung Crystal 4K Vivid' or 'Find the best TV with Google OS and 3 HDMI ports.'"}
            </p>
          </div>

        </div>
      </section>

      {/* Trust & Knowledge Banner */}
      <footer className="bg-white border-t border-slate-200 py-3.5 px-6 text-center text-[10px] text-slate-400 font-medium shrink-0 flex flex-col sm:flex-row justify-between items-center gap-2">
        <div className="flex items-center gap-1">
          <Shield className="w-3.5 h-3.5 text-indigo-500" />
          <span>ShopAI utilizes live web grounding & specifications to guarantee shopping accuracy across all customers.</span>
        </div>
        <div className="flex items-center gap-3 text-[11px]">
          <span className="flex items-center gap-1"><Lightbulb className="w-3.5 h-3.5 text-amber-500" /> Live specs updated using Google Grounded Search</span>
          <span>© 2026 ShopAI Corp</span>
        </div>
      </footer>

      {/* High-Fidelity Authentication Portal Modal */}
      {authModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 md:p-8 shadow-2xl relative border border-slate-100 overflow-hidden flex flex-col gap-4 max-h-[90vh] overflow-y-auto animate-in fade-in duration-200">
            
            {/* Top Close Button */}
            <button
              onClick={() => setAuthModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition p-1 rounded-full hover:bg-slate-50 cursor-pointer"
            >
              <Trash2 className="w-4 h-4 rotate-45" />
            </button>

            {/* Shield Icon Header */}
            <div className="text-center space-y-1">
              <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto shadow-md">
                <Shield className="w-6 h-6 stroke-[2]" />
              </div>
              <h3 className="text-lg font-extrabold text-slate-900">
                {authMode === "login" ? "Sign In to ShopAI" : "Build ShopAI Account"}
              </h3>
              <p className="text-xs text-slate-400">
                Save wishlists, compare criteria, and track query sessions
              </p>
            </div>

            {/* Tab switchers */}
            <div className="grid grid-cols-2 bg-slate-100 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => {
                  setAuthMode("login");
                  setAuthError(null);
                }}
                className={`py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  authMode === "login"
                    ? "bg-white text-slate-900 shadow-sm"
                    : "text-slate-500 hover:text-slate-900"
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode("signup");
                  setAuthError(null);
                }}
                className={`py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  authMode === "signup"
                    ? "bg-white text-slate-900 shadow-sm"
                    : "text-slate-500 hover:text-slate-900"
                }`}
              >
                Create Account
              </button>
            </div>

            {/* Error Message */}
            {authError && (
              <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-xl text-xs flex items-start gap-2 animate-pulse">
                <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <span className="font-medium">{authError}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleAuthSubmit} className="space-y-3">
              {authMode === "signup" && (
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Enter your name (e.g. Rahul Sharma)"
                    value={authName}
                    onChange={(e) => setAuthName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl text-xs outline-none focus:bg-white text-slate-800"
                  />
                </div>
              )}

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl text-xs outline-none focus:bg-white text-slate-800"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Password</label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 focus:border-amber-400 rounded-xl text-xs outline-none focus:bg-white text-slate-800"
                />
              </div>

              <button
                type="submit"
                disabled={authLoading}
                className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl transition text-xs shadow-md shadow-amber-500/10 flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer"
              >
                {authLoading ? (
                  <span className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span>
                ) : (
                  <span>{authMode === "login" ? "Sign In to My Account" : "Register and Open Account"}</span>
                )}
              </button>
            </form>

            <div className="relative my-1">
              <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-slate-100"></span></div>
              <div className="relative flex justify-center text-[10px] uppercase font-bold text-slate-400"><span className="bg-white px-2">or Sandbox bypass</span></div>
            </div>

            {/* Quick Bypass options */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={handleDemoBypass}
                className="w-full py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold rounded-xl transition text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                <span>Continue as Local Sandbox Guest</span>
              </button>

              {/* Dynamic Information Box */}
              <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl space-y-1.5">
                <div className="flex items-center gap-1.5 text-[10px] font-bold text-indigo-700">
                  <Shield className="w-3.5 h-3.5" />
                  <span>Cloud Database Sandbox Info:</span>
                </div>
                <p className="text-[10px] text-slate-500 leading-relaxed text-left">
                  {firebaseEnabled ? (
                    "✔️ Live Cloud Mode Active: This form will authenticate you directly through your live Firebase project."
                  ) : (
                    "💡 Operating in Local Demo Mode because no Firebase credentials are loaded yet. Simply fill the form to register a local demo profile or click 'Local Sandbox Guest'. Run the 'set_up_firebase' tool in AI Studio to instantly make this a production-ready cloud synced shopping assistant!"
                  )}
                </p>
              </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
