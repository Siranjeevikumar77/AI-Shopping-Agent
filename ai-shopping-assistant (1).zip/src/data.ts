import { Product } from "./types";

export interface CategoryConfig {
  id: "laptop" | "mobile" | "tv" | "other";
  label: string;
  icon: string;
  defaultBudget: number;
  specKeys: string[];
  sliderLabels: {
    weight1: string;
    weight2: string;
    weight3: string;
    weight4: string;
    weight5: string;
  };
}

export const CATEGORIES: CategoryConfig[] = [
  {
    id: "laptop",
    label: "Laptops",
    icon: "💻",
    defaultBudget: 60000,
    specKeys: ["Processor", "Graphics/GPU", "RAM Memory", "Storage", "Display/Screen", "Battery/Power"],
    sliderLabels: {
      weight1: "Coding Performance (CPU)",
      weight2: "Gaming Power (GPU)",
      weight3: "Battery Longevity",
      weight4: "Display/Screen Quality",
      weight5: "Portability & Slimness",
    },
  },
  {
    id: "mobile",
    label: "Mobiles",
    icon: "📱",
    defaultBudget: 25000,
    specKeys: ["Processor", "Display", "Camera", "RAM/Storage", "Battery/Charging", "Operating System"],
    sliderLabels: {
      weight1: "Processing Power (Gaming/Supa)",
      weight2: "Camera Capabilities",
      weight3: "Battery Backup & Fast Charge",
      weight4: "AMOLED Display Quality",
      weight5: "Sleek Build & Software",
    },
  },
  {
    id: "tv",
    label: "Smart TVs",
    icon: "📺",
    defaultBudget: 30000,
    specKeys: ["Screen Size", "Display Tech", "Refresh Rate", "Sound Output", "Smart OS", "Connectivity"],
    sliderLabels: {
      weight1: "Cinematic Display Quality",
      weight2: "Sound Stage & Audio Output",
      weight3: "Smart TV OS & Apps",
      weight4: "Connectivity (HDMI ports)",
      weight5: "Smooth Refresh (Gaming)",
    },
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  // LAPTOPS
  {
    id: "laptop-1",
    category: "laptop",
    name: "ASUS TUF Gaming F15 (2023)",
    price: "₹57,990",
    rating: 5,
    specs: {
      "Processor": "Intel Core i5-11400H (6 Cores, 12 Threads, up to 4.5 GHz)",
      "Graphics/GPU": "NVIDIA GeForce RTX 3050 (4GB GDDR6)",
      "RAM Memory": "16GB DDR4 3200MHz (Dual Channel)",
      "Storage": "512GB NVMe PCIe 3.0 SSD",
      "Display/Screen": "15.6'' Full HD (1920x1080) 144Hz IPS Anti-Glare",
      "Battery/Power": "48Whr Battery (Approx 3.5 hours for work)"
    },
    pros: ["RTX 3050 GPU gives stellar graphics rendering", "Military-grade MIL-STD-810H durability", "Excellent dual-fan cooling tech"],
    cons: ["11th Gen CPU is slightly older architecture", "Relatively bulky and heavy (2.3kg)"]
  },
  {
    id: "laptop-2",
    category: "laptop",
    name: "HP Victus 15 (Ryzen Edition)",
    price: "₹56,990",
    rating: 4,
    specs: {
      "Processor": "AMD Ryzen 5 5600H (6 Cores, 12 Threads, up to 4.2 GHz)",
      "Graphics/GPU": "NVIDIA GeForce RTX 2050 (4GB GDDR6)",
      "RAM Memory": "16GB DDR4 3200MHz",
      "Storage": "512GB PCIe Gen4 NVMe SSD",
      "Display/Screen": "15.6'' Full HD (1920x1080) 144Hz IPS Micro-edge",
      "Battery/Power": "52.5Whr Battery (Approx 4.5-5 hours for office work)"
    },
    pros: ["AMD Zen 3 architecture provides exceptional battery life", "Understated, professional aesthetic fit for office/college", "Fast Gen4 SSD storage support"],
    cons: ["RTX 2050 graphics performance is 20-25% slower than RTX 3050", "Screen has slight wobble on fast typing"]
  },
  {
    id: "laptop-3",
    category: "laptop",
    name: "Lenovo IdeaPad Gaming 3",
    price: "₹59,990",
    rating: 4,
    specs: {
      "Processor": "AMD Ryzen 5 6600H (6 Cores, 12 Threads, up to 4.5 GHz)",
      "Graphics/GPU": "NVIDIA GeForce RTX 3050 (4GB GDDR6)",
      "RAM Memory": "8GB DDR5 4800MHz (Upgradable to 16GB)",
      "Storage": "512GB PCIe NVMe M.2 SSD",
      "Display/Screen": "15.6'' FHD (1920x1080) 120Hz IPS-level 250nits",
      "Battery/Power": "45Whr Battery with Rapid Charge (30 min to 50%)"
    },
    pros: ["Next-Gen Zen 3+ 6nm processor with DDR5 support", "Legendary tactile keyboard with 1.5mm key travel", "Decent thermal ventilation vents"],
    cons: ["Comes with only 8GB RAM (16GB highly recommended)", "Power brick is rather large"]
  },
  {
    id: "laptop-4",
    category: "laptop",
    name: "Apple MacBook Air M2",
    price: "₹89,900",
    rating: 5,
    specs: {
      "Processor": "Apple M2 Chip (8-Core CPU with 4 performance & 4 efficiency cores)",
      "Graphics/GPU": "8-Core Apple Integrated GPU",
      "RAM Memory": "8GB Unified Memory",
      "Storage": "256GB Superfast SSD Storage",
      "Display/Screen": "13.6'' Liquid Retina Display (2560x1664) with 500 nits brightness",
      "Battery/Power": "52.6Whr Battery (Up to 18 hours of web surfing)"
    },
    pros: ["Industry-leading battery life & zero fan noise design", "Stunningly slim 11.3mm profile weighing just 1.24kg", "Superb dynamic speakers and gorgeous Retina panel"],
    cons: ["Base model storage is slower (256GB single-chip)", "Supports only 1 external display natively"]
  },
  {
    id: "laptop-5",
    category: "laptop",
    name: "Apple MacBook Air M3",
    price: "₹1,04,900",
    rating: 5,
    specs: {
      "Processor": "Apple M3 Chip (8-Core CPU, 3nm architecture)",
      "Graphics/GPU": "10-Core Apple GPU with hardware-accelerated ray tracing",
      "RAM Memory": "16GB Unified Memory (Configured)",
      "Storage": "512GB High-Speed SSD",
      "Display/Screen": "13.6'' Liquid Retina Display (2560x1664) with True Tone",
      "Battery/Power": "52.6Whr Battery (Up to 18 hours real-world use)"
    },
    pros: ["Hardware-accelerated ray tracing for premium rendering", "Dual external monitor support when laptop lid is closed", "16GB unified RAM handles multi-tasking effortlessly"],
    cons: ["Higher price point", "Ports are limited to two Thunderbolt/USB-C slots"]
  },
  {
    id: "laptop-6",
    category: "laptop",
    name: "Dell Inspiron 15 3520",
    price: "₹47,990",
    rating: 4,
    specs: {
      "Processor": "Intel Core i5-1235U (10 Cores, 12 Threads, up to 4.40 GHz)",
      "Graphics/GPU": "Intel Iris Xe Graphics",
      "RAM Memory": "16GB DDR4 3200MHz",
      "Storage": "512GB M.2 PCIe NVMe SSD",
      "Display/Screen": "15.6'' FHD (1920x1080) 120Hz IPS-level Display",
      "Battery/Power": "41Whr Battery with ExpressCharge (80% in 1 hour)"
    },
    pros: ["Superb 16GB dual channel RAM for smooth office/productivity", "Smooth 120Hz refresh rate display keeps animations fluid", "Ergonomic lift hinge elevates typing stance comfortably"],
    cons: ["Plastic construction instead of premium metal", "Average battery back-up (approx 4 hours) due to small 41Whr cell"]
  },
  {
    id: "laptop-7",
    category: "laptop",
    name: "Lenovo Yoga Slim 7i Carbon",
    price: "₹1,12,990",
    rating: 5,
    specs: {
      "Processor": "Intel Core Ultra 7 155H (16 Cores, 22 Threads with built-in AI NPU)",
      "Graphics/GPU": "Intel Arc Graphics",
      "RAM Memory": "16GB LPDDR5X 7467MHz",
      "Storage": "1TB PCIe Gen4 NVMe M.2 SSD",
      "Display/Screen": "14'' 2.8K (2880x1800) 120Hz PureSight OLED Touchscreen (400 nits)",
      "Battery/Power": "65Whr Battery with 65W USB-C PD Charger"
    },
    pros: ["Extremely lightweight Carbon design weighing less than 1kg", "Ultra-vibrant 2.8K OLED with 100% DCI-P3 color gamut", "Intel Core Ultra AI accelerator optimizes local model rendering"],
    cons: ["RAM is soldered on and non-upgradable", "Expensive choice"]
  },
  {
    id: "laptop-8",
    category: "laptop",
    name: "Acer Aspire Lite (Thin & Light)",
    price: "₹28,990",
    rating: 4,
    specs: {
      "Processor": "Intel Core i3-1215U (6 Cores, 8 Threads, up to 4.4 GHz)",
      "Graphics/GPU": "Intel UHD Graphics",
      "RAM Memory": "8GB DDR4 (Upgradable to 32GB)",
      "Storage": "512GB NVMe PCIe SSD",
      "Display/Screen": "15.6'' Full HD (1920x1080) Slim-Bezel Anti-Glare",
      "Battery/Power": "36Whr Battery (Approx 3 hours productivity)"
    },
    pros: ["Highly affordable with full metal chassis cover", "180-degree hinge layout for versatile viewing angles", "Numeric keypad included for finance/office tasks"],
    cons: ["Basic entry-level display panel with limited viewing angles", "Not suited for gaming or video editing"]
  },
  {
    id: "laptop-9",
    category: "laptop",
    name: "Acer Predator Helios 16",
    price: "₹1,44,990",
    rating: 5,
    specs: {
      "Processor": "Intel Core i7-13700HX (16 Cores, 24 Threads, up to 5.00 GHz)",
      "Graphics/GPU": "NVIDIA GeForce RTX 4060 (8GB GDDR6, 140W TGP)",
      "RAM Memory": "16GB DDR5 4800MHz (Dual-channel)",
      "Storage": "1TB NVMe PCIe Gen4 SSD",
      "Display/Screen": "16'' WQXGA (2560x1600) 240Hz IPS, 500 nits, G-Sync",
      "Battery/Power": "90Whr high-capacity Battery with 330W Adapter"
    },
    pros: ["Ultimate RTX 4060 gaming power with a massive 140W TGP", "Extremely smooth 240Hz screen ideal for esports competitive play", "Stellar Liquid Metal thermal interface keeps temperatures cool"],
    cons: ["Extremely heavy (2.6kg) with a bulky 330W charging brick", "Terrible battery life (lasts under 2.5 hours on casual work)"]
  },
  {
    id: "laptop-10",
    category: "laptop",
    name: "Samsung Galaxy Book4 Pro",
    price: "₹1,24,990",
    rating: 5,
    specs: {
      "Processor": "Intel Core Ultra 5 125H (14 Cores, 18 Threads, Intel AI NPU)",
      "Graphics/GPU": "Intel Arc Graphics",
      "RAM Memory": "16GB LPDDR5X RAM",
      "Storage": "512GB PCIe Gen4 SSD (Dual slots)",
      "Display/Screen": "14'' Dynamic AMOLED 2X Touch (2880x1800) 120Hz, VRR",
      "Battery/Power": "63Whr Battery with 65W USB-C fast charging"
    },
    pros: ["Breathtaking premium 120Hz Dynamic AMOLED display", "Seamless ecosystem synergy with Samsung phones/tablets", "Incredibly thin profile (11.6mm) and long battery runtime"],
    cons: ["Premium price segment", "Intel Arc is only suitable for casual, entry-level gaming"]
  },

  // MOBILES
  {
    id: "mobile-1",
    category: "mobile",
    name: "OnePlus Nord CE4",
    price: "₹24,999",
    rating: 5,
    specs: {
      "Processor": "Qualcomm Snapdragon 7 Gen 3 (Octa-core, 4nm)",
      "Display": "6.7'' Full HD+ 120Hz Fluid AMOLED (1100 nits)",
      "Camera": "50MP Sony LYT-600 (OIS) + 8MP Ultra-wide | 16MP Selfie",
      "RAM/Storage": "8GB LPDDR4X RAM | 128GB UFS 3.1",
      "Battery/Charging": "5500mAh Battery with 100W SuperVOOC Fast Charge",
      "Operating System": "OxygenOS 14 based on Android 14"
    },
    pros: ["Superb 100W fast charge (0 to 100% in 29 mins)", "Powerful Snapdragon 7 Gen 3 performs lag-free", "Beautiful high-contrast fluid AMOLED screen"],
    cons: ["Plastic back frame", "No 3.5mm headphone jack"]
  },
  {
    id: "mobile-2",
    category: "mobile",
    name: "Samsung Galaxy A35 5G",
    price: "₹27,999",
    rating: 4,
    specs: {
      "Processor": "Exynos 1380 (5nm Octa-core)",
      "Display": "6.6'' FHD+ 120Hz Super AMOLED (1000 nits)",
      "Camera": "50MP Main (OIS) + 8MP Wide + 5MP Macro | 13MP Selfie",
      "RAM/Storage": "8GB RAM | 128GB Storage (Upgradable via MicroSD)",
      "Battery/Charging": "5000mAh Battery with 25W Charging support",
      "Operating System": "One UI 6.1 based on Android 14 (4 Years OS Updates)"
    },
    pros: ["Gorilla Glass Victus+ premium build and IP67 rating", "Stunning Samsung Super AMOLED panel with vivid colors", "Industry-leading 4 years OS updates guarantee"],
    cons: ["Exynos 1380 processor is weaker for high-end heavy gaming", "No charger in the box"]
  },
  {
    id: "mobile-3",
    category: "mobile",
    name: "Redmi Note 13 Pro 5G",
    price: "₹25,999",
    rating: 4,
    specs: {
      "Processor": "Snapdragon 7s Gen 2 (4nm Process)",
      "Display": "6.67'' 1.5K 120Hz CrystalRes AMOLED (1800 nits)",
      "Camera": "200MP Ultra-High Res (OIS) + 8MP + 2MP | 16MP Front",
      "RAM/Storage": "8GB LPDDR4X RAM | 256GB UFS 2.2 Storage",
      "Battery/Charging": "5100mAh Battery with 67W Turbo Charge (In-box charger)",
      "Operating System": "HyperOS based on Android 14"
    },
    pros: ["200MP camera captures outstanding crop zoom detail", "Stellar 1.5K display is crisp and bright under direct sunlight", "Comes with 256GB generous base storage"],
    cons: ["UFS 2.2 storage speed is slower than UFS 3.1", "Some bloatware pre-installed"]
  },
  {
    id: "mobile-4",
    category: "mobile",
    name: "Apple iPhone 15",
    price: "₹71,999",
    rating: 5,
    specs: {
      "Processor": "Apple A16 Bionic (4nm, 6-core)",
      "Display": "6.1'' Super Retina XDR OLED (2000 nits peak, Dynamic Island)",
      "Camera": "48MP Main (f/1.6, Sensor-shift OIS) + 12MP Ultra-wide | 12MP TrueDepth",
      "RAM/Storage": "6GB RAM | 128GB/256GB/512GB Storage",
      "Battery/Charging": "3349mAh Battery with 20W USB-C PD Charging",
      "Operating System": "iOS 17 (Upgradable to iOS 18)"
    },
    pros: ["Interactive Dynamic Island is highly functional", "Superb 48MP primary camera yields ultra-detailed 24MP default shots", "Premium color-infused glass back design"],
    cons: ["Display is locked at a basic 60Hz refresh rate", "Charging speed is relatively slow at ~20W"]
  },
  {
    id: "mobile-5",
    category: "mobile",
    name: "Samsung Galaxy S24 Ultra",
    price: "₹1,29,999",
    rating: 5,
    specs: {
      "Processor": "Snapdragon 8 Gen 3 for Galaxy (4nm)",
      "Display": "6.8'' Dynamic AMOLED 2X (120Hz, 2600 nits, Anti-Reflective)",
      "Camera": "200MP Main + 50MP Periscope (5x optical) + 10MP Telephoto (3x) + 12MP Ultra-wide",
      "RAM/Storage": "12GB LPDDR5X | 256GB/512GB UFS 4.0",
      "Battery/Charging": "5000mAh Battery with 45W Fast Charging & 15W wireless",
      "Operating System": "One UI 6.1 (7 Years of security & software updates)"
    },
    pros: ["Stunning Titanium frame with anti-reflective glass screen", "Legendary S-Pen stylus included in body", "7 years of full OS updates guaranteed"],
    cons: ["Very expensive", "A bit blocky and heavy to hold (232g)"]
  },
  {
    id: "mobile-6",
    category: "mobile",
    name: "OnePlus 12R 5G",
    price: "₹39,999",
    rating: 5,
    specs: {
      "Processor": "Qualcomm Snapdragon 8 Gen 2 (4nm Flagship SoC)",
      "Display": "6.78'' 1.5K 120Hz ProXDR LTPO 4.0 Display (4500 nits peak)",
      "Camera": "50MP Sony IMX890 (OIS) + 8MP Ultra-wide + 2MP Macro | 16MP Front",
      "RAM/Storage": "8GB/16GB LPDDR5X | 128GB UFS 3.1 or 256GB UFS 4.0",
      "Battery/Charging": "5500mAh massive Battery with 100W SuperVOOC Charger",
      "Operating System": "OxygenOS 14 based on Android 14"
    },
    pros: ["Flagship Snapdragon 8 Gen 2 performance at mid-tier cost", "Mind-blowing 5500mAh battery outlasts almost all smartphones", "Stunning ProXDR display with ultra-high contrast levels"],
    cons: ["Secondary camera sensors (8MP + 2MP) are mediocre", "No wireless charging support"]
  },
  {
    id: "mobile-7",
    category: "mobile",
    name: "Vivo V30 Pro 5G",
    price: "₹41,999",
    rating: 4,
    specs: {
      "Processor": "MediaTek Dimensity 8200 (4nm process)",
      "Display": "6.78'' 1.5K 3D Curved AMOLED (120Hz, 2800 nits)",
      "Camera": "50MP Zeiss OIS + 50MP Zeiss Portrait + 50MP Zeiss Wide | 50MP Eye-AF Selfie",
      "RAM/Storage": "8GB/128GB or 12GB/512GB Options",
      "Battery/Charging": "5000mAh Battery with 80W FlashCharge",
      "Operating System": "Funtouch OS 14 based on Android 14"
    },
    pros: ["All 4 cameras (3 rear, 1 front) are outstanding 50MP Zeiss sensors", "Incredibly slim (7.45mm) build with beautiful matte finishes", "Zeiss style bokeh effects make portraits look professional"],
    cons: ["Curved screen is prone to accidental touches and drops", "Mono-like or standard speaker setup"]
  },
  {
    id: "mobile-8",
    category: "mobile",
    name: "Motorola Edge 50 Pro",
    price: "₹31,999",
    rating: 5,
    specs: {
      "Processor": "Qualcomm Snapdragon 7 Gen 3 (4nm)",
      "Display": "6.7'' 1.5K 144Hz pOLED Curved screen (Pantone Validated)",
      "Camera": "50MP Main OIS + 10MP Telephoto (3x optical) + 13MP Wide/Macro",
      "RAM/Storage": "12GB LPDDR4X | 256GB UFS 2.2 Storage",
      "Battery/Charging": "4500mAh Battery with 125W TurboPower wire & 50W wireless",
      "Operating System": "Hello UI based on Android 14 (No bloatware)"
    },
    pros: ["Crazy fast 125W wired and 50W wireless charging speeds", "Pantone validated skin tone colors on both screen and camera", "Super-clean, pure stock Android user experience"],
    cons: ["UFS 2.2 storage protocol is dated", "4500mAh battery is slightly smaller than current 5000mAh standards"]
  },
  {
    id: "mobile-9",
    category: "mobile",
    name: "POCO X6 Pro 5G",
    price: "₹26,999",
    rating: 5,
    specs: {
      "Processor": "MediaTek Dimensity 8300 Ultra (4nm, AnTuTu Score ~1.4M+)",
      "Display": "6.67'' 1.5K 120Hz Flow AMOLED (1800 nits peak)",
      "Camera": "64MP Main (OIS) + 8MP Ultra-wide + 2MP Macro",
      "RAM/Storage": "12GB LPDDR5X | 512GB UFS 4.0 Storage",
      "Battery/Charging": "5000mAh Battery with 67W Fast Charging",
      "Operating System": "Xiaomi HyperOS based on Android 14"
    },
    pros: ["Incredible Dimensity 8300 Ultra chip yields unmatched gaming FPS", "Premium 12GB LPDDR5X and 512GB UFS 4.0 base configuration", "Extremely thin bezels provide a highly immersive screen feel"],
    cons: ["Plastic build gets warm during continuous heavy stress gaming", "Secondary cameras are average"]
  },
  {
    id: "mobile-10",
    category: "mobile",
    name: "Moto G64 5G (Budget)",
    price: "₹14,999",
    rating: 4,
    specs: {
      "Processor": "MediaTek Dimensity 7025 (6nm)",
      "Display": "6.5'' Full HD+ 120Hz IPS LCD Display",
      "Camera": "50MP Main (OIS) + 8MP Macro/Depth | 16MP Selfie",
      "RAM/Storage": "12GB RAM | 256GB Storage (Upgradable to 1TB)",
      "Battery/Charging": "6000mAh massive Battery with 33W Charger (In-box)",
      "Operating System": "My UX clean Android 14"
    },
    pros: ["Massive 6000mAh battery easily lasts up to 2 days", "Comes with OIS camera support which is rare in this budget tier", "Industry-first Dimensity 7025 offers smooth day-to-day work"],
    cons: ["IPS LCD screen instead of an AMOLED panel", "33W charging takes around 1.5 hours to fully fuel the 6000mAh cell"]
  },

  // SMART TVS
  {
    id: "tv-1",
    category: "tv",
    name: "Xiaomi Smart TV X Series (43\")",
    price: "₹24,999",
    rating: 5,
    specs: {
      "Screen Size": "43 Inches",
      "Display Tech": "4K Ultra HD (3840x2160) | Dolby Vision, HDR10, Vivid Picture Engine",
      "Refresh Rate": "60 Hz",
      "Sound Output": "30W Speakers with Dolby Audio & DTS-HD & DTS:X",
      "Smart OS": "Google TV with PatchWall & Chromecast Built-in",
      "Connectivity": "3 HDMI ports (1 eARC), 2 USB ports, Dual-band Wi-Fi, Bluetooth 5.0"
    },
    pros: ["Dolby Vision 4K display at a highly competitive price", "30W loud cinematic sound output", "PatchWall offers superb smart content recommendations"],
    cons: ["60Hz is basic (no native VRR for gaming console)", "Average contrast in pitch dark rooms"]
  },
  {
    id: "tv-2",
    category: "tv",
    name: "OnePlus TV Y1S Pro (43\")",
    price: "₹23,999",
    rating: 4,
    specs: {
      "Screen Size": "43 Inches",
      "Display Tech": "4K Ultra HD (3840x2160) | Gamma Engine, HDR10+, HLG",
      "Refresh Rate": "60 Hz",
      "Sound Output": "24W Speakers with Dolby Audio",
      "Smart OS": "Android TV 11 with OxygenPlay 2.0 & Google Assistant",
      "Connectivity": "3 HDMI, 2 USB, Bluetooth 5.0, Wi-Fi 5G"
    },
    pros: ["OnePlus Connect 2.0 lets you control TV via smartphone", "Gamma Engine yields highly accurate skin tones", "Bezel-less premium modern design"],
    cons: ["Slightly lower speaker output (24W) compared to Xiaomi", "Android TV 11 is slightly older than Google TV interface"]
  },
  {
    id: "tv-3",
    category: "tv",
    name: "Samsung Crystal 4K Vivid (43\")",
    price: "₹28,990",
    rating: 4,
    specs: {
      "Screen Size": "43 Inches",
      "Display Tech": "4K Ultra HD Crystal Processor | HDR10+, PurColor",
      "Refresh Rate": "50 Hz",
      "Sound Output": "20W Speakers with OTS Lite (Object Tracking Sound)",
      "Smart OS": "Tizen Smart TV OS (supports SmartThings Hub & Bixby)",
      "Connectivity": "3 HDMI, 1 USB, Optical Audio Out, Bluetooth 4.2"
    },
    pros: ["Outstanding upscaling to 4K of standard definition content", "OTS Lite audio tracks moving objects for immersive sound", "Samsung brand value with stellar build and reliability"],
    cons: ["A bit expensive for a 43\" size", "Tizen app library is slightly smaller than Google Play Store"]
  }
];
