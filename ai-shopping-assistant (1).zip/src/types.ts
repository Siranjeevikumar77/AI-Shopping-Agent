export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
}

export interface GroundingMetadata {
  groundingChunks?: GroundingChunk[];
  webSearchQueries?: string[];
}

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  groundingMetadata?: GroundingMetadata;
  products?: Product[];
}

export interface Product {
  id: string;
  category: "laptop" | "mobile" | "tv" | "other";
  name: string;
  price: string;
  rating: number; // 1-5 stars
  specs: { [key: string]: string }; // Dynamic key-value specification dictionary
  pros: string[];
  cons: string[];
}

export interface User {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  createdAt?: string;
  isDemo?: boolean;
}

